/*
# Add unique index on voucher_entries for safe re-sync

## Purpose
The sync-ingest edge function upserts voucher line items into voucher_entries.
Previously there was no unique constraint, so the onConflict clause errored
and line items were never persisted. This migration adds a unique index that
treats NULL ledger_name as empty string (for inventory-only entries) and
includes stock_item_id so multiple inventory lines on the same voucher don't
collide.

## Changes
1. voucher_entries: unique index on (company_id, voucher_type, voucher_number,
   voucher_date, COALESCE(ledger_name,''), COALESCE(stock_item_id, sentinel uuid)).

## Security
- No new tables, no policy changes. RLS already enabled on voucher_entries.
*/

CREATE UNIQUE INDEX IF NOT EXISTS idx_voucher_entries_dedup
ON voucher_entries (
  company_id, voucher_type, voucher_number, voucher_date,
  COALESCE(ledger_name, ''),
  COALESCE(stock_item_id, '00000000-0000-0000-0000-000000000000'::uuid)
);
