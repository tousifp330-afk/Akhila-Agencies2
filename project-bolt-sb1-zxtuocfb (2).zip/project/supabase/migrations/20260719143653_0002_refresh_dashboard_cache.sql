/*
# Dashboard cache refresh function

## Purpose
Provides `refresh_dashboard_cache(p_company_id uuid)` which recomputes the
ERP dashboard summary for a given company and upserts it into
`dashboard_cache`. Called by edge functions after each sync run.

## What it computes
- outstanding_receivables, outstanding_payables
- bank_balance, cash_balance
- current_stock_value
- top_debtors, top_creditors (top 10 by amount)
- sales_total, purchases_total (sum of voucher totals)
- cash_flow (receipts - payments)
- recent_activity (last 20 sync_logs + voucher inserts)

## Notes
- Uses the materialized `outstanding_balances` and `dashboard_cache` tables.
- Safe to call repeatedly; idempotent upsert.
*/

CREATE OR REPLACE FUNCTION refresh_dashboard_cache(p_company_id uuid)
RETURNS jsonb LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE
  result jsonb;
  v_receivables numeric(18,3);
  v_payables numeric(18,3);
  v_bank_balance numeric(18,3);
  v_cash_balance numeric(18,3);
  v_stock_value numeric(18,3);
  v_sales_total numeric(18,3);
  v_purchases_total numeric(18,3);
  v_receipts_total numeric(18,3);
  v_payments_total numeric(18,3);
  v_top_debtors jsonb;
  v_top_creditors jsonb;
  v_recent_activity jsonb;
BEGIN
  SELECT COALESCE(sum(amount),0) INTO v_receivables
    FROM outstanding_balances
    WHERE company_id = p_company_id AND kind = 'receivable';

  SELECT COALESCE(sum(amount),0) INTO v_payables
    FROM outstanding_balances
    WHERE company_id = p_company_id AND kind = 'payable';

  SELECT COALESCE(sum(current_balance),0) INTO v_bank_balance
    FROM bank_accounts WHERE company_id = p_company_id;

  SELECT COALESCE(sum(current_balance),0) INTO v_cash_balance
    FROM cash_accounts WHERE company_id = p_company_id;

  SELECT COALESCE(sum(current_value),0) INTO v_stock_value
    FROM stock_items WHERE company_id = p_company_id;

  SELECT COALESCE(sum(total_amount),0) INTO v_sales_total
    FROM sales_vouchers WHERE company_id = p_company_id;

  SELECT COALESCE(sum(total_amount),0) INTO v_purchases_total
    FROM purchase_vouchers WHERE company_id = p_company_id;

  SELECT COALESCE(sum(amount),0) INTO v_receipts_total
    FROM receipt_vouchers WHERE company_id = p_company_id;

  SELECT COALESCE(sum(amount),0) INTO v_payments_total
    FROM payment_vouchers WHERE company_id = p_company_id;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'ledger_name', ledger_name, 'amount', amount
  ) ORDER BY amount DESC) FILTER (WHERE amount > 0), '[]'::jsonb) INTO v_top_debtors
  FROM outstanding_balances
  WHERE company_id = p_company_id AND kind = 'receivable'
  LIMIT 10;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'ledger_name', ledger_name, 'amount', amount
  ) ORDER BY amount DESC) FILTER (WHERE amount > 0), '[]'::jsonb) INTO v_top_creditors
  FROM outstanding_balances
  WHERE company_id = p_company_id AND kind = 'payable'
  LIMIT 10;

  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'type', voucher_type, 'number', voucher_number, 'date', voucher_date, 'narration', narration
  ) ORDER BY voucher_date DESC, id DESC) FILTER (WHERE true), '[]'::jsonb) INTO v_recent_activity
  FROM (
    SELECT 'Sales' AS voucher_type, voucher_number, voucher_date, narration, id
    FROM sales_vouchers WHERE company_id = p_company_id
    UNION ALL
    SELECT 'Purchase', voucher_number, voucher_date, narration, id
    FROM purchase_vouchers WHERE company_id = p_company_id
    UNION ALL
    SELECT 'Receipt', voucher_number, voucher_date, narration, id
    FROM receipt_vouchers WHERE company_id = p_company_id
    UNION ALL
    SELECT 'Payment', voucher_number, voucher_date, narration, id
    FROM payment_vouchers WHERE company_id = p_company_id
    ORDER BY voucher_date DESC, id DESC
    LIMIT 20
  ) AS r;

  result := jsonb_build_object(
    'company_id', p_company_id,
    'outstanding_receivables', v_receivables,
    'outstanding_payables', v_payables,
    'bank_balance', v_bank_balance,
    'cash_balance', v_cash_balance,
    'current_stock_value', v_stock_value,
    'sales_total', v_sales_total,
    'purchases_total', v_purchases_total,
    'receipts_total', v_receipts_total,
    'payments_total', v_payments_total,
    'cash_flow', v_receipts_total - v_payments_total,
    'top_debtors', v_top_debtors,
    'top_creditors', v_top_creditors,
    'recent_activity', v_recent_activity,
    'computed_at', now()
  );

  INSERT INTO dashboard_cache (company_id, payload, computed_at)
  VALUES (p_company_id, result, now())
  ON CONFLICT (company_id) DO UPDATE
    SET payload = EXCLUDED.payload,
        computed_at = now();

  RETURN result;
END;
$$;
