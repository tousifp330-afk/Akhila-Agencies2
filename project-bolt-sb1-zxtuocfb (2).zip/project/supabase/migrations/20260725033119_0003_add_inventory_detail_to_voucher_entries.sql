/*
# Add inventory detail columns to voucher_entries

## Purpose
The voucher_entries table already stores ledger line items (debit, credit,
quantity, rate, stock_item_id, godown_id) but is missing HSN codes and batch
names that Tally exports on inventory entries. This migration adds those two
columns so sales/purchase inventory lines carry full GST + batch detail,
enabling correct stock valuation, HSN reporting, and batch tracking on the
website without ever showing 0 quantity / 0 rate / 0 value when Tally holds
non-zero data.

## Changes
1. voucher_entries: add `hsn` (text, nullable) — HSN/SAC code from the inventory entry.
2. voucher_entries: add `batch_name` (text, nullable) — batch identifier from batch allocations.

## Security
- No new tables. No policy changes. RLS already enabled on voucher_entries.
- Existing CRUD policies remain unchanged and still apply.

## Notes
- Both columns are nullable so existing rows are unaffected.
- The sync-ingest edge function will populate them going forward.
- No data is lost; this is purely additive.
*/

ALTER TABLE voucher_entries ADD COLUMN IF NOT EXISTS hsn text;
ALTER TABLE voucher_entries ADD COLUMN IF NOT EXISTS batch_name text;
