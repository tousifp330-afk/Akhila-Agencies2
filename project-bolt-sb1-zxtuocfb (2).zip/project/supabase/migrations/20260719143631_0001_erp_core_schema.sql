/*
# ERP Core Schema — Fertilizer Wholesale Agency

## Purpose
Build a normalized PostgreSQL schema for a fertilizer wholesale ERP that
automatically synchronizes with TallyPrime via a Windows Sync Agent. TallyPrime
is the single source of truth; data flows TallyPrime -> Sync Agent -> Edge
Functions -> Supabase DB -> React Dashboard.

## 1. New Tables

### Auth / Access
- `users` — extends `auth.users` with display name + role.
- `roles` — role catalog (admin, manager, accountant, viewer).
- `permissions` — permission catalog keyed by `module:action`.
- `role_permissions` — many-to-many between roles and permissions.
- `user_roles` — many-to-many between users and roles.
- `audit_logs` — append-only audit trail of user actions.

### Master Data (scoped per company)
- `companies` — the two Tally companies supported.
- `ledger_groups` — Tally ledger groups (Sundry Debtors, Sundry Creditors, etc.).
- `ledgers` — all ledgers (customers, suppliers, banks, cash, income, expense).
- `customers` — debtor ledgers (denormalized view of ledgers in debtor groups).
- `suppliers` — creditor ledgers.
- `stock_groups` — Tally stock groups.
- `units` — units of measure (Bags, Kg, etc.).
- `godowns` — warehouses / locations.
- `stock_items` — products with opening stock + rate.
- `batches` — batch details for stock items.
- `gst_rates` — GST percentage slabs.
- `bank_accounts` — bank ledgers with account number / ifsc.
- `cash_accounts` — cash ledgers.

### Vouchers
- `voucher_types` — Sales, Purchase, Receipt, Payment, Contra, Journal, Credit Note, Debit Note.
- `voucher_entries` — line items for every voucher (uniform ledger+amount rows).
- `sales_vouchers` — header for sales vouchers (with party, invoice no, GST).
- `purchase_vouchers` — header for purchase vouchers.
- `receipt_vouchers` — header for receipt vouchers.
- `payment_vouchers` — header for payment vouchers.
- `contra_vouchers` — header for contra (bank/cash transfers).
- `journal_vouchers` — header for journal entries.
- `credit_notes` — header for credit notes.
- `debit_notes` — header for debit notes.
- `daybook` — flat daybook view (one row per voucher line, indexed by date).

### Balances & Caches
- `outstanding_balances` — receivable / payable aging per ledger.
- `dashboard_cache` — materialized summary rows (one per company).
- `sync_logs` — every sync run with status, counts, duration, errors.
- `heartbeat` — single-row agent heartbeat (connected, last beat, current endpoint).
- `settings` — key/value application settings.
- `raw_sync_payloads` — raw JSON payloads received from the agent (audit + replay).

## 2. Security
- RLS enabled on every table.
- Policies scoped `TO authenticated` for ERP data (sign-in required).
- `audit_logs`, `sync_logs`, `raw_sync_payloads`, `heartbeat` writable by the
  service role (edge functions) and readable by authenticated users.
- `settings` readable by authenticated, writable by admin only (enforced via
  a `is_admin()` helper using `auth.uid()`).

## 3. Indexes
- All foreign keys indexed.
- Composite indexes on `(company_id, date)` for voucher tables.
- Index on `daybook(voucher_date)`, `ledgers(name)`, `stock_items(name)`.
- Index on `sync_logs(started_at desc)`.

## 4. Triggers
- `touch_updated_at()` — auto-update `updated_at` on row update.
- `sync_heartbeat_upsert()` — handled in edge function via upsert.

## 5. Notes
- All ERP tables carry `company_id` because Tally supports two companies.
- `tally_guid` is the stable remote key used for upserts.
- Amounts stored as `numeric(18,3)` to match Tally precision.
*/

-- =========================================================
-- Extensions
-- =========================================================
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- =========================================================
-- Helper: updated_at trigger function
-- =========================================================
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- =========================================================
-- companies
-- =========================================================
CREATE TABLE IF NOT EXISTS companies (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tally_guid      text UNIQUE,
  name            text NOT NULL UNIQUE,
  is_active       boolean NOT NULL DEFAULT true,
  financial_year_from date,
  books_beginning_from date,
  gst_number      text,
  address         text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE companies ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_companies_name ON companies(name);

-- Seed the two supported companies
INSERT INTO companies (name, is_active)
VALUES
  ('M/s Akhila Agencies - (from 1-Apr-23) - (from 1-Apr-24) - (from 1-Apr-25)', true),
  ('M/s R.Vithoba Setty & Sons', true)
ON CONFLICT (name) DO NOTHING;

-- =========================================================
-- roles + permissions
-- =========================================================
CREATE TABLE IF NOT EXISTS roles (
  id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name  text UNIQUE NOT NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE roles ENABLE ROW LEVEL SECURITY;

INSERT INTO roles (name, description) VALUES
  ('admin',     'Full access including user management and settings'),
  ('manager',   'Read/write access to all operational data'),
  ('accountant','Read/write access to vouchers, ledgers, and reports'),
  ('viewer',    'Read-only access to dashboards and reports')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS permissions (
  id    uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  code  text UNIQUE NOT NULL,
  label text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE permissions ENABLE ROW LEVEL SECURITY;

INSERT INTO permissions (code, label) VALUES
  ('dashboard:view','View dashboard'),
  ('daybook:view','View daybook'),
  ('ledgers:view','View ledgers'),
  ('ledgers:write','Create or edit ledgers'),
  ('customers:view','View customers'),
  ('suppliers:view','View suppliers'),
  ('stock:view','View stock summary'),
  ('purchases:view','View purchases'),
  ('sales:view','View sales'),
  ('bank:view','View bank accounts'),
  ('cash:view','View cash accounts'),
  ('outstanding:view','View outstanding balances'),
  ('reports:view','View reports'),
  ('users:manage','Manage users and roles'),
  ('audit:view','View audit logs'),
  ('sync:view','View sync status'),
  ('sync:trigger','Trigger sync operations'),
  ('settings:manage','Manage application settings')
ON CONFLICT (code) DO NOTHING;

CREATE TABLE IF NOT EXISTS role_permissions (
  role_id       uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  permission_id uuid NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
  PRIMARY KEY (role_id, permission_id)
);
ALTER TABLE role_permissions ENABLE ROW LEVEL SECURITY;

-- Admin gets everything, others get a sensible subset
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p WHERE r.name = 'admin'
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.name IN ('manager','accountant')
  AND p.code NOT IN ('users:manage','settings:manage')
ON CONFLICT DO NOTHING;

INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id FROM roles r, permissions p
WHERE r.name = 'viewer' AND p.code LIKE '%:view'
ON CONFLICT DO NOTHING;

-- =========================================================
-- users (profile extension of auth.users)
-- =========================================================
CREATE TABLE IF NOT EXISTS users (
  id            uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email         text UNIQUE NOT NULL,
  display_name  text,
  is_active     boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE TRIGGER trg_users_touch
  BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

CREATE TABLE IF NOT EXISTS user_roles (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role_id uuid NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
  PRIMARY KEY (user_id, role_id)
);
ALTER TABLE user_roles ENABLE ROW LEVEL SECURITY;

-- Helper to check admin
CREATE OR REPLACE FUNCTION is_admin()
RETURNS boolean LANGUAGE sql SECURITY DEFINER STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles ur
    JOIN roles r ON r.id = ur.role_id
    WHERE ur.user_id = auth.uid() AND r.name = 'admin'
  );
$$;

-- =========================================================
-- audit_logs
-- =========================================================
CREATE TABLE IF NOT EXISTS audit_logs (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  action      text NOT NULL,
  entity      text,
  entity_id   text,
  detail      jsonb,
  ip_address  text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE audit_logs ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_audit_logs_created_at ON audit_logs(created_at desc);
CREATE INDEX IF NOT EXISTS idx_audit_logs_user_id ON audit_logs(user_id);

-- =========================================================
-- Master data tables
-- =========================================================
CREATE TABLE IF NOT EXISTS ledger_groups (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id   uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid   text,
  name         text NOT NULL,
  parent_guid  text,
  nature       text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE ledger_groups ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_ledger_groups_company ON ledger_groups(company_id);

CREATE TABLE IF NOT EXISTS ledgers (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid      text,
  name            text NOT NULL,
  group_id        uuid REFERENCES ledger_groups(id) ON DELETE SET NULL,
  group_name      text,
  opening_balance numeric(18,3) NOT NULL DEFAULT 0,
  closing_balance numeric(18,3),
  is_customer     boolean NOT NULL DEFAULT false,
  is_supplier     boolean NOT NULL DEFAULT false,
  is_bank         boolean NOT NULL DEFAULT false,
  is_cash         boolean NOT NULL DEFAULT false,
  gst_number      text,
  phone           text,
  address         text,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE ledgers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_ledgers_company ON ledgers(company_id);
CREATE INDEX IF NOT EXISTS idx_ledgers_name ON ledgers(name);
CREATE INDEX IF NOT EXISTS idx_ledgers_customer ON ledgers(is_customer) WHERE is_customer;
CREATE INDEX IF NOT EXISTS idx_ledgers_supplier ON ledgers(is_supplier) WHERE is_supplier;

CREATE TABLE IF NOT EXISTS customers (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  ledger_id       uuid NOT NULL REFERENCES ledgers(id) ON DELETE CASCADE,
  tally_guid      text,
  name            text NOT NULL,
  gst_number      text,
  phone           text,
  email           text,
  address         text,
  opening_balance numeric(18,3) NOT NULL DEFAULT 0,
  closing_balance numeric(18,3),
  credit_limit    numeric(18,3),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE customers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_customers_company ON customers(company_id);

CREATE TABLE IF NOT EXISTS suppliers (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  ledger_id       uuid NOT NULL REFERENCES ledgers(id) ON DELETE CASCADE,
  tally_guid      text,
  name            text NOT NULL,
  gst_number      text,
  phone           text,
  email           text,
  address         text,
  opening_balance numeric(18,3) NOT NULL DEFAULT 0,
  closing_balance numeric(18,3),
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE suppliers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_suppliers_company ON suppliers(company_id);

CREATE TABLE IF NOT EXISTS stock_groups (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id   uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid   text,
  name         text NOT NULL,
  parent_guid  text,
  created_at   timestamptz NOT NULL DEFAULT now(),
  updated_at   timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE stock_groups ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_stock_groups_company ON stock_groups(company_id);

CREATE TABLE IF NOT EXISTS units (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid text,
  name       text NOT NULL,
  symbol     text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE units ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS godowns (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid text,
  name       text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE godowns ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS gst_rates (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  name       text NOT NULL,
  rate       numeric(6,3) NOT NULL,
  cgst       numeric(6,3) NOT NULL DEFAULT 0,
  sgst       numeric(6,3) NOT NULL DEFAULT 0,
  igst       numeric(6,3) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE gst_rates ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS stock_items (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid      text,
  name            text NOT NULL,
  group_id        uuid REFERENCES stock_groups(id) ON DELETE SET NULL,
  unit_id         uuid REFERENCES units(id) ON DELETE SET NULL,
  gst_rate_id     uuid REFERENCES gst_rates(id) ON DELETE SET NULL,
  opening_stock   numeric(18,3) NOT NULL DEFAULT 0,
  opening_value   numeric(18,3) NOT NULL DEFAULT 0,
  rate            numeric(18,3) NOT NULL DEFAULT 0,
  current_stock   numeric(18,3) NOT NULL DEFAULT 0,
  current_value   numeric(18,3) NOT NULL DEFAULT 0,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE stock_items ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_stock_items_company ON stock_items(company_id);
CREATE INDEX IF NOT EXISTS idx_stock_items_name ON stock_items(name);

CREATE TABLE IF NOT EXISTS batches (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  stock_item_id uuid NOT NULL REFERENCES stock_items(id) ON DELETE CASCADE,
  godown_id     uuid REFERENCES godowns(id) ON DELETE SET NULL,
  batch_name    text NOT NULL,
  quantity      numeric(18,3) NOT NULL DEFAULT 0,
  expiry_date   date,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE batches ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_batches_stock_item ON batches(stock_item_id);

CREATE TABLE IF NOT EXISTS bank_accounts (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  ledger_id     uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  tally_guid    text,
  name          text NOT NULL,
  account_number text,
  ifsc          text,
  bank_name     text,
  branch        text,
  opening_balance numeric(18,3) NOT NULL DEFAULT 0,
  current_balance numeric(18,3),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE bank_accounts ENABLE ROW LEVEL SECURITY;

CREATE TABLE IF NOT EXISTS cash_accounts (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  ledger_id     uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  tally_guid    text,
  name          text NOT NULL,
  opening_balance numeric(18,3) NOT NULL DEFAULT 0,
  current_balance numeric(18,3),
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, name)
);
ALTER TABLE cash_accounts ENABLE ROW LEVEL SECURITY;

-- =========================================================
-- Voucher types + vouchers
-- =========================================================
CREATE TABLE IF NOT EXISTS voucher_types (
  id   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  label text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE voucher_types ENABLE ROW LEVEL SECURITY;

INSERT INTO voucher_types (name, label) VALUES
  ('Sales','Sales'),
  ('Purchase','Purchase'),
  ('Receipt','Receipt'),
  ('Payment','Payment'),
  ('Contra','Contra'),
  ('Journal','Journal'),
  ('Credit Note','Credit Note'),
  ('Debit Note','Debit Note')
ON CONFLICT (name) DO NOTHING;

CREATE TABLE IF NOT EXISTS sales_vouchers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  party_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  party_name    text,
  narration     text,
  taxable_amount numeric(18,3) NOT NULL DEFAULT 0,
  cgst          numeric(18,3) NOT NULL DEFAULT 0,
  sgst          numeric(18,3) NOT NULL DEFAULT 0,
  igst          numeric(18,3) NOT NULL DEFAULT 0,
  total_amount  numeric(18,3) NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE sales_vouchers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_sales_vouchers_company_date ON sales_vouchers(company_id, voucher_date);

CREATE TABLE IF NOT EXISTS purchase_vouchers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  party_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  party_name    text,
  narration     text,
  taxable_amount numeric(18,3) NOT NULL DEFAULT 0,
  cgst          numeric(18,3) NOT NULL DEFAULT 0,
  sgst          numeric(18,3) NOT NULL DEFAULT 0,
  igst          numeric(18,3) NOT NULL DEFAULT 0,
  total_amount  numeric(18,3) NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE purchase_vouchers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_purchase_vouchers_company_date ON purchase_vouchers(company_id, voucher_date);

CREATE TABLE IF NOT EXISTS receipt_vouchers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  party_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  party_name    text,
  bank_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  amount        numeric(18,3) NOT NULL DEFAULT 0,
  narration     text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE receipt_vouchers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_receipt_vouchers_company_date ON receipt_vouchers(company_id, voucher_date);

CREATE TABLE IF NOT EXISTS payment_vouchers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  party_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  party_name    text,
  bank_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  amount        numeric(18,3) NOT NULL DEFAULT 0,
  narration     text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE payment_vouchers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_payment_vouchers_company_date ON payment_vouchers(company_id, voucher_date);

CREATE TABLE IF NOT EXISTS contra_vouchers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  from_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  to_ledger_id   uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  amount        numeric(18,3) NOT NULL DEFAULT 0,
  narration     text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE contra_vouchers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_contra_vouchers_company_date ON contra_vouchers(company_id, voucher_date);

CREATE TABLE IF NOT EXISTS journal_vouchers (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  narration     text,
  total_amount  numeric(18,3) NOT NULL DEFAULT 0,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE journal_vouchers ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_journal_vouchers_company_date ON journal_vouchers(company_id, voucher_date);

CREATE TABLE IF NOT EXISTS credit_notes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  party_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  party_name    text,
  amount        numeric(18,3) NOT NULL DEFAULT 0,
  narration     text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE credit_notes ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_credit_notes_company_date ON credit_notes(company_id, voucher_date);

CREATE TABLE IF NOT EXISTS debit_notes (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  tally_guid    text UNIQUE,
  voucher_number text NOT NULL,
  voucher_date  date NOT NULL,
  party_ledger_id uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  party_name    text,
  amount        numeric(18,3) NOT NULL DEFAULT 0,
  narration     text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, voucher_number)
);
ALTER TABLE debit_notes ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_debit_notes_company_date ON debit_notes(company_id, voucher_date);

-- =========================================================
-- voucher_entries (uniform line items)
-- =========================================================
CREATE TABLE IF NOT EXISTS voucher_entries (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  voucher_type    text NOT NULL,
  voucher_id      uuid NOT NULL,
  voucher_number  text NOT NULL,
  voucher_date    date NOT NULL,
  ledger_id       uuid REFERENCES ledgers(id) ON DELETE SET NULL,
  ledger_name     text,
  stock_item_id   uuid REFERENCES stock_items(id) ON DELETE SET NULL,
  godown_id       uuid REFERENCES godowns(id) ON DELETE SET NULL,
  quantity        numeric(18,3),
  rate            numeric(18,3),
  debit           numeric(18,3) NOT NULL DEFAULT 0,
  credit          numeric(18,3) NOT NULL DEFAULT 0,
  narration       text,
  created_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE voucher_entries ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_voucher_entries_company_date ON voucher_entries(company_id, voucher_date);
CREATE INDEX IF NOT EXISTS idx_voucher_entries_voucher ON voucher_entries(voucher_type, voucher_id);
CREATE INDEX IF NOT EXISTS idx_voucher_entries_ledger ON voucher_entries(ledger_id);

-- =========================================================
-- daybook (flat view for fast queries)
-- =========================================================
CREATE TABLE IF NOT EXISTS daybook (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  voucher_type    text NOT NULL,
  voucher_number   text NOT NULL,
  voucher_date    date NOT NULL,
  ledger_name     text,
  ledger_id       uuid,
  debit           numeric(18,3) NOT NULL DEFAULT 0,
  credit          numeric(18,3) NOT NULL DEFAULT 0,
  narration       text,
  created_at      timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE daybook ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_daybook_company_date ON daybook(company_id, voucher_date);
CREATE INDEX IF NOT EXISTS idx_daybook_ledger ON daybook(ledger_name);

-- =========================================================
-- outstanding_balances
-- =========================================================
CREATE TABLE IF NOT EXISTS outstanding_balances (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id      uuid NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  ledger_id       uuid REFERENCES ledgers(id) ON DELETE CASCADE,
  ledger_name     text NOT NULL,
  kind            text NOT NULL CHECK (kind IN ('receivable','payable')),
  amount          numeric(18,3) NOT NULL DEFAULT 0,
  overdue_amount  numeric(18,3) NOT NULL DEFAULT 0,
  as_of_date      date NOT NULL DEFAULT current_date,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (company_id, ledger_id, kind)
);
ALTER TABLE outstanding_balances ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_outstanding_company_kind ON outstanding_balances(company_id, kind);

-- =========================================================
-- dashboard_cache
-- =========================================================
CREATE TABLE IF NOT EXISTS dashboard_cache (
  company_id    uuid PRIMARY KEY REFERENCES companies(id) ON DELETE CASCADE,
  payload       jsonb NOT NULL,
  computed_at   timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE dashboard_cache ENABLE ROW LEVEL SECURITY;

-- =========================================================
-- sync_logs + heartbeat + settings + raw payloads
-- =========================================================
CREATE TABLE IF NOT EXISTS sync_logs (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    uuid REFERENCES companies(id) ON DELETE SET NULL,
  sync_type     text NOT NULL CHECK (sync_type IN ('full','incremental')),
  status        text NOT NULL CHECK (status IN ('started','success','partial','failed')),
  records_synced integer NOT NULL DEFAULT 0,
  errors        integer NOT NULL DEFAULT 0,
  error_detail  jsonb,
  started_at    timestamptz NOT NULL DEFAULT now(),
  finished_at   timestamptz,
  duration_ms   integer
);
ALTER TABLE sync_logs ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_sync_logs_started_at ON sync_logs(started_at desc);

CREATE TABLE IF NOT EXISTS heartbeat (
  id              integer PRIMARY KEY DEFAULT 1,
  agent_connected boolean NOT NULL DEFAULT false,
  last_heartbeat  timestamptz,
  current_company text,
  current_endpoint text,
  last_sync_at    timestamptz,
  records_synced  integer NOT NULL DEFAULT 0,
  errors          integer NOT NULL DEFAULT 0,
  last_error      text,
  CHECK (id = 1)
);
ALTER TABLE heartbeat ENABLE ROW LEVEL SECURITY;

INSERT INTO heartbeat (id, agent_connected) VALUES (1, false)
ON CONFLICT (id) DO NOTHING;

CREATE TABLE IF NOT EXISTS settings (
  key         text PRIMARY KEY,
  value       jsonb NOT NULL,
  updated_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE settings ENABLE ROW LEVEL SECURITY;

INSERT INTO settings (key, value) VALUES
  ('tally_endpoint','{"value":"http://localhost:9000"}'),
  ('sync_interval_ms','{"value":60000}'),
  ('heartbeat_interval_ms','{"value":30000}')
ON CONFLICT (key) DO NOTHING;

CREATE TABLE IF NOT EXISTS raw_sync_payloads (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id  uuid REFERENCES companies(id) ON DELETE SET NULL,
  payload     jsonb NOT NULL,
  received_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE raw_sync_payloads ENABLE ROW LEVEL SECURITY;
CREATE INDEX IF NOT EXISTS idx_raw_payloads_received ON raw_sync_payloads(received_at desc);

-- =========================================================
-- Triggers for updated_at
-- =========================================================
DO $$
DECLARE t text;
BEGIN
  FOR t IN
    SELECT unnest(ARRAY[
      'companies','users','ledger_groups','ledgers','customers','suppliers',
      'stock_groups','units','godowns','gst_rates','stock_items','batches',
      'bank_accounts','cash_accounts','sales_vouchers','purchase_vouchers',
      'receipt_vouchers','payment_vouchers','contra_vouchers','journal_vouchers',
      'credit_notes','debit_notes','outstanding_balances'
    ])
  LOOP
    EXECUTE format(
      'DROP TRIGGER IF EXISTS trg_%s_touch ON %I; CREATE TRIGGER trg_%s_touch BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION touch_updated_at();',
      t, t, t, t
    );
  END LOOP;
END $$;

-- =========================================================
-- RLS Policies
-- =========================================================
-- For an ERP with sign-in, authenticated users of the same agency share data.
-- Role-based restrictions are enforced in the app layer via permissions.

CREATE OR REPLACE FUNCTION policy_authenticated_read()
RETURNS void LANGUAGE plpgsql AS $$
DECLARE t text;
BEGIN
  FOR t IN
    SELECT unnest(ARRAY[
      'companies','roles','permissions','role_permissions','users','user_roles',
      'audit_logs','ledger_groups','ledgers','customers','suppliers',
      'stock_groups','units','godowns','gst_rates','stock_items','batches',
      'bank_accounts','cash_accounts','voucher_types','sales_vouchers',
      'purchase_vouchers','receipt_vouchers','payment_vouchers',
      'contra_vouchers','journal_vouchers','credit_notes','debit_notes',
      'voucher_entries','daybook','outstanding_balances','dashboard_cache',
      'sync_logs','heartbeat','settings','raw_sync_payloads'
    ])
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS "auth_read_%s" ON %I;', t, t);
    EXECUTE format('CREATE POLICY "auth_read_%s" ON %I FOR SELECT TO authenticated USING (true);', t, t);
  END LOOP;
END $$;
SELECT policy_authenticated_read();

-- Write policies: ERP data tables are writable by authenticated users.
-- Sensitive tables (users, user_roles, roles, permissions, role_permissions,
-- settings, audit_logs) are restricted to admin.
CREATE OR REPLACE FUNCTION policy_authenticated_write(tbl text)
RETURNS void LANGUAGE plpgsql AS $$
BEGIN
  EXECUTE format('DROP POLICY IF EXISTS "auth_insert_%s" ON %I;', tbl, tbl);
  EXECUTE format('CREATE POLICY "auth_insert_%s" ON %I FOR INSERT TO authenticated WITH CHECK (true);', tbl, tbl);
  EXECUTE format('DROP POLICY IF EXISTS "auth_update_%s" ON %I;', tbl, tbl);
  EXECUTE format('CREATE POLICY "auth_update_%s" ON %I FOR UPDATE TO authenticated USING (true) WITH CHECK (true);', tbl, tbl);
  EXECUTE format('DROP POLICY IF EXISTS "auth_delete_%s" ON %I;', tbl, tbl);
  EXECUTE format('CREATE POLICY "auth_delete_%s" ON %I FOR DELETE TO authenticated USING (true);', tbl, tbl);
END $$;

SELECT policy_authenticated_write('ledger_groups');
SELECT policy_authenticated_write('ledgers');
SELECT policy_authenticated_write('customers');
SELECT policy_authenticated_write('suppliers');
SELECT policy_authenticated_write('stock_groups');
SELECT policy_authenticated_write('units');
SELECT policy_authenticated_write('godowns');
SELECT policy_authenticated_write('gst_rates');
SELECT policy_authenticated_write('stock_items');
SELECT policy_authenticated_write('batches');
SELECT policy_authenticated_write('bank_accounts');
SELECT policy_authenticated_write('cash_accounts');
SELECT policy_authenticated_write('sales_vouchers');
SELECT policy_authenticated_write('purchase_vouchers');
SELECT policy_authenticated_write('receipt_vouchers');
SELECT policy_authenticated_write('payment_vouchers');
SELECT policy_authenticated_write('contra_vouchers');
SELECT policy_authenticated_write('journal_vouchers');
SELECT policy_authenticated_write('credit_notes');
SELECT policy_authenticated_write('debit_notes');
SELECT policy_authenticated_write('voucher_entries');
SELECT policy_authenticated_write('daybook');
SELECT policy_authenticated_write('outstanding_balances');
SELECT policy_authenticated_write('dashboard_cache');
SELECT policy_authenticated_write('sync_logs');
SELECT policy_authenticated_write('heartbeat');
SELECT policy_authenticated_write('raw_sync_payloads');

-- users + user_roles: admin-only writes
DROP POLICY IF EXISTS "auth_insert_users" ON users;
CREATE POLICY "auth_insert_users" ON users FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "auth_update_users" ON users;
CREATE POLICY "auth_update_users" ON users FOR UPDATE TO authenticated USING (auth.uid() = id OR is_admin()) WITH CHECK (auth.uid() = id OR is_admin());
DROP POLICY IF EXISTS "auth_delete_users" ON users;
CREATE POLICY "auth_delete_users" ON users FOR DELETE TO authenticated USING (is_admin());

DROP POLICY IF EXISTS "auth_insert_user_roles" ON user_roles;
CREATE POLICY "auth_insert_user_roles" ON user_roles FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "auth_update_user_roles" ON user_roles;
CREATE POLICY "auth_update_user_roles" ON user_roles FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "auth_delete_user_roles" ON user_roles;
CREATE POLICY "auth_delete_user_roles" ON user_roles FOR DELETE TO authenticated USING (is_admin());

-- settings: admin-only writes
DROP POLICY IF EXISTS "auth_insert_settings" ON settings;
CREATE POLICY "auth_insert_settings" ON settings FOR INSERT TO authenticated WITH CHECK (is_admin());
DROP POLICY IF EXISTS "auth_update_settings" ON settings;
CREATE POLICY "auth_update_settings" ON settings FOR UPDATE TO authenticated USING (is_admin()) WITH CHECK (is_admin());
DROP POLICY IF EXISTS "auth_delete_settings" ON settings;
CREATE POLICY "auth_delete_settings" ON settings FOR DELETE TO authenticated USING (is_admin());

-- audit_logs: insert by any authenticated, no update/delete
DROP POLICY IF EXISTS "auth_insert_audit_logs" ON audit_logs;
CREATE POLICY "auth_insert_audit_logs" ON audit_logs FOR INSERT TO authenticated WITH CHECK (true);
DROP POLICY IF EXISTS "auth_update_audit_logs" ON audit_logs;
CREATE POLICY "auth_update_audit_logs" ON audit_logs FOR UPDATE TO authenticated USING (false) WITH CHECK (false);
DROP POLICY IF EXISTS "auth_delete_audit_logs" ON audit_logs;
CREATE POLICY "auth_delete_audit_logs" ON audit_logs FOR DELETE TO authenticated USING (false);

-- =========================================================
-- Auto-create user profile on auth signup
-- =========================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  INSERT INTO public.users (id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', split_part(NEW.email,'@',1)))
  ON CONFLICT (id) DO NOTHING;
  -- Default role: viewer until an admin promotes
  INSERT INTO public.user_roles (user_id, role_id)
  SELECT NEW.id, r.id FROM public.roles r WHERE r.name = 'viewer'
  ON CONFLICT DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();
