/*
# Fix dashboard cache to compute from ledgers + stock_items

## Purpose
The dashboard_cache RPC currently sums from bank_accounts, cash_accounts,
outstanding_balances, sales_vouchers, purchase_vouchers tables. But these
tables are empty because the sync agent derives bank/cash/outstanding from
ledger closing balances, and vouchers may not sync on all TallyPrime versions.
This update makes the RPC compute bank balance, cash balance, outstanding
receivables/payables, and top debtors/creditors directly from the ledgers
table (which is always populated by master sync). Sales/purchases still come
from voucher tables when available, falling back to 0.

## Changes
1. Replace bank_accounts sum with sum of ledgers where is_bank = true
2. Replace cash_accounts sum with sum of ledgers where is_cash = true
3. Replace outstanding_balances sums with sum of ledgers where is_customer/is_supplier
4. Top debtors/creditors from ledgers instead of outstanding_balances

## Security
- No new tables, no policy changes. Only modifies the RPC function.
*/

CREATE OR REPLACE FUNCTION refresh_dashboard_cache(p_company_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  result jsonb;
  v_receivables numeric(18,3);
  v_payables numeric(18,3);
  v_bank_balance numeric(18,3);
  v_cash_balance numeric(18,3);
  v_stock_value numeric(18,3);
  v_sales_total numeric(18,3);
  v_purchases_total numeric(18,3);
  v_receipts_total numeric(18,3);
  v_payments_total numeric(18,3);
  v_top_debtors jsonb;
  v_top_creditors jsonb;
  v_recent_activity jsonb;
BEGIN
  -- Outstanding receivables: debtors with positive closing balance
  SELECT COALESCE(sum(ABS(closing_balance)), 0)
    INTO v_receivables
  FROM ledgers
  WHERE company_id = p_company_id
    AND is_customer = true
    AND closing_balance IS NOT NULL
    AND closing_balance != 0;

  -- Outstanding payables: creditors with positive closing balance
  SELECT COALESCE(sum(ABS(closing_balance)), 0)
    INTO v_payables
  FROM ledgers
  WHERE company_id = p_company_id
    AND is_supplier = true
    AND closing_balance IS NOT NULL
    AND closing_balance != 0;

  -- Bank balance: sum of bank ledgers' closing balances
  SELECT COALESCE(sum(ABS(closing_balance)), 0)
    INTO v_bank_balance
  FROM ledgers
  WHERE company_id = p_company_id
    AND is_bank = true
    AND closing_balance IS NOT NULL;

  -- Cash balance: sum of cash ledgers' closing balances
  SELECT COALESCE(sum(ABS(closing_balance)), 0)
    INTO v_cash_balance
  FROM ledgers
  WHERE company_id = p_company_id
    AND is_cash = true
    AND closing_balance IS NOT NULL;

  -- Stock value from stock_items
  SELECT COALESCE(sum(current_value), 0)
    INTO v_stock_value
  FROM stock_items
  WHERE company_id = p_company_id;

  -- Sales/purchases from voucher tables (may be 0 if vouchers haven't synced yet)
  SELECT COALESCE(sum(total_amount), 0) INTO v_sales_total
  FROM sales_vouchers WHERE company_id = p_company_id;

  SELECT COALESCE(sum(total_amount), 0) INTO v_purchases_total
  FROM purchase_vouchers WHERE company_id = p_company_id;

  SELECT COALESCE(sum(amount), 0) INTO v_receipts_total
  FROM receipt_vouchers WHERE company_id = p_company_id;

  SELECT COALESCE(sum(amount), 0) INTO v_payments_total
  FROM payment_vouchers WHERE company_id = p_company_id;

  -- Top debtors from ledgers
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'ledger_name', name, 'amount', ABS(closing_balance)
  ) ORDER BY ABS(closing_balance) DESC) FILTER (WHERE ABS(closing_balance) > 0), '[]'::jsonb)
    INTO v_top_debtors
  FROM ledgers
  WHERE company_id = p_company_id
    AND is_customer = true
    AND closing_balance IS NOT NULL
    AND closing_balance != 0
  LIMIT 10;

  -- Top creditors from ledgers
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'ledger_name', name, 'amount', ABS(closing_balance)
  ) ORDER BY ABS(closing_balance) DESC) FILTER (WHERE ABS(closing_balance) > 0), '[]'::jsonb)
    INTO v_top_creditors
  FROM ledgers
  WHERE company_id = p_company_id
    AND is_supplier = true
    AND closing_balance IS NOT NULL
    AND closing_balance != 0
  LIMIT 10;

  -- Recent activity from voucher tables
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'type', voucher_type, 'number', voucher_number, 'date', voucher_date, 'narration', narration
  ) ORDER BY voucher_date DESC, id DESC) FILTER (WHERE true), '[]'::jsonb)
    INTO v_recent_activity
  FROM (
    SELECT 'Sales' AS voucher_type, voucher_number, voucher_date, narration, id
    FROM sales_vouchers WHERE company_id = p_company_id
    UNION ALL
    SELECT 'Purchase', voucher_number, voucher_date, narration, id
    FROM purchase_vouchers WHERE company_id = p_company_id
    UNION ALL
    SELECT 'Receipt', voucher_number, voucher_date, narration, id
    FROM receipt_vouchers WHERE company_id = p_company_id
    UNION ALL
    SELECT 'Payment', voucher_number, voucher_date, narration, id
    FROM payment_vouchers WHERE company_id = p_company_id
    ORDER BY voucher_date DESC, id DESC
    LIMIT 20
  ) AS r;

  result := jsonb_build_object(
    'company_id', p_company_id,
    'outstanding_receivables', v_receivables,
    'outstanding_payables', v_payables,
    'bank_balance', v_bank_balance,
    'cash_balance', v_cash_balance,
    'current_stock_value', v_stock_value,
    'sales_total', v_sales_total,
    'purchases_total', v_purchases_total,
    'receipts_total', v_receipts_total,
    'payments_total', v_payments_total,
    'cash_flow', v_receipts_total - v_payments_total,
    'top_debtors', v_top_debtors,
    'top_creditors', v_top_creditors,
    'recent_activity', v_recent_activity,
    'computed_at', now()
  );

  INSERT INTO dashboard_cache (company_id, payload, computed_at)
  VALUES (p_company_id, result, now())
  ON CONFLICT (company_id) DO UPDATE
  SET payload = EXCLUDED.payload,
      computed_at = now();

  RETURN result;
END;
$$;
