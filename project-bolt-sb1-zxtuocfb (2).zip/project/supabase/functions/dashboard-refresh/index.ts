import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  try {
    const url = new URL(req.url);
    const companyName = url.searchParams.get("company");
    let companyId: string | null = null;

    if (companyName) {
      const { data } = await supabase.from("companies")
        .select("id").eq("name", companyName).maybeSingle();
      companyId = data?.id ?? null;
    }

    if (!companyId) {
      const { data } = await supabase.from("companies").select("id, name").limit(1).maybeSingle();
      companyId = data?.id ?? null;
    }

    if (!companyId) {
      return new Response(JSON.stringify({ error: "No companies configured" }), {
        status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data, error } = await supabase.rpc("refresh_dashboard_cache", { p_company_id: companyId });
    if (error) throw error;

    return new Response(JSON.stringify({ success: true, payload: data }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ success: false, error: e.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
