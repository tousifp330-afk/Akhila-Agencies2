import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  let body: any;
  try { body = await req.json(); } catch { body = {}; }

  const now = new Date().toISOString();
  const update: any = {
    id: 1,
    agent_connected: true,
    last_heartbeat: now,
    current_company: body.current_company ?? null,
    current_endpoint: body.current_endpoint ?? null,
    last_sync_at: body.last_sync_at ?? null,
    records_synced: body.records_synced ?? 0,
    errors: body.errors ?? 0,
    last_error: body.last_error ?? null,
  };

  const { error } = await supabase.from("heartbeat").upsert(update, { onConflict: "id" });
  if (error) {
    return new Response(JSON.stringify({ success: false, error: error.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Check if user requested a force full sync from the Settings page
  let force_full_sync = false;
  const { data: syncCmd } = await supabase
    .from("settings")
    .select("key, value")
    .eq("key", "force_full_sync")
    .maybeSingle();
  if (syncCmd?.value?.value === true) {
    force_full_sync = true;
    // Clear the flag
    await supabase
      .from("settings")
      .upsert({ key: "force_full_sync", value: { value: false, requested_at: syncCmd.value.requested_at } }, { onConflict: "key" });
  }

  return new Response(JSON.stringify({ success: true, received_at: now, force_full_sync }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
});
