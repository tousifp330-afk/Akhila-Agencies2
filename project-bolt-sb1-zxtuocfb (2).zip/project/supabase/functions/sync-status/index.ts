import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  try {
    const [hb, recentLogs, lastSync] = await Promise.all([
      supabase.from("heartbeat").select("*").eq("id", 1).maybeSingle(),
      supabase.from("sync_logs").select("*").order("started_at", { ascending: false }).limit(20),
      supabase.from("sync_logs").select("*").order("started_at", { ascending: false }).limit(1).maybeSingle(),
    ]);

    return new Response(JSON.stringify({
      heartbeat: hb.data,
      recent_logs: recentLogs.data,
      last_sync: lastSync.data,
    }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: e.message }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
