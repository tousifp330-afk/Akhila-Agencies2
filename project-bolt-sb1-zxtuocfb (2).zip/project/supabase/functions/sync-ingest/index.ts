import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const CHUNK = 100; // rows per upsert batch

function num(v: any): number {
  if (v === null || v === undefined || v === "") return 0;
  const s = typeof v === "string" ? v.replace(/,/g, "").trim() : String(v);
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : 0;
}

function str(v: any): string | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s.length ? s : null;
}

function date(v: any): string | null {
  if (!v) return null;
  const s = String(v).trim();
  if (!s) return null;
  if (/^\d{8}$/.test(s)) return `${s.slice(0,4)}-${s.slice(4,6)}-${s.slice(6,8)}`;
  if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0,10);
  const m = s.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
  if (m) return `${m[3]}-${m[2].padStart(2,"0")}-${m[1].padStart(2,"0")}`;
  return null;
}

// Deduplicate rows by the conflict key columns before upserting.
// PostgreSQL throws "ON CONFLICT DO UPDATE command cannot affect a row a second time"
// when the same unique key appears more than once in a single INSERT batch.
function deduplicateRows(rows: any[], conflict: string): any[] {
  const keys = conflict.split(",").map(k => k.trim());
  const seen = new Set<string>();
  return rows.filter(row => {
    const fingerprint = keys.map(k => String(row[k] ?? "")).join("|");
    if (seen.has(fingerprint)) return false;
    seen.add(fingerprint);
    return true;
  });
}

// Bulk upsert in chunks — never more than CHUNK rows per request.
async function bulkUpsert(
  supabase: any,
  table: string,
  rows: any[],
  conflict: string,
  stats: Record<string,number>,
  errors: string[],
  logger: (s:string)=>void,
): Promise<void> {
  if (!rows.length) return;
  const deduped = deduplicateRows(rows, conflict);
  const total = deduped.length;
  const chunks = Math.ceil(total / CHUNK);
  let done = 0;
  for (let i = 0; i < total; i += CHUNK) {
    const batch = deduped.slice(i, i + CHUNK);
    done++;
    logger(`Uploading ${table} batch ${done} of ${chunks} (${batch.length} rows)`);
    const { error } = await supabase.from(table).upsert(batch, { onConflict: conflict });
    if (error) {
      errors.push(`${table} batch ${done}: ${error.message}`);
    } else {
      stats[table] = (stats[table] || 0) + batch.length;
    }
  }
}

const COMPANY_NAMES = [
  "M/s Akhila Agencies - (from 1-Apr-23) - (from 1-Apr-24) - (from 1-Apr-25)",
  "M/s R.Vithoba Setty & Sons",
];

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { status: 200, headers: corsHeaders });
  if (req.method !== "POST") return jsonError(405, "Method not allowed");

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  let payload: any;
  try { payload = await req.json(); }
  catch (e) { return jsonError(400, "Invalid JSON: " + e.message); }

  if (!payload.company_name || !payload.records) return jsonError(400, "Missing company_name or records");
  if (!COMPANY_NAMES.includes(payload.company_name)) return jsonError(400, `Unsupported company: ${payload.company_name}`);

  const { data: company } = await supabase.from("companies").select("id").eq("name", payload.company_name).maybeSingle();
  if (!company) return jsonError(404, "Company not found: " + payload.company_name);
  const companyId = company.id;

  // Store raw payload (fire and forget — don't block sync on this)
  supabase.from("raw_sync_payloads").insert({ company_id: companyId, payload }).then(() => {});

  const startedAt = payload.started_at ? new Date(payload.started_at) : new Date();
  const { data: syncLog } = await supabase.from("sync_logs").insert({
    company_id: companyId, sync_type: payload.sync_type,
    status: "started", started_at: startedAt.toISOString(),
  }).select().maybeSingle();

  const stats: Record<string,number> = {};
  const errors: string[] = [];
  const logs: string[] = [];
  const log = (s: string) => { logs.push(s); console.log(s); };

  try {
    const r = payload.records;

    // For full syncs, clear transactional tables first (masters are upserted, not deleted)
    if (payload.sync_type === "full") {
      log("Full sync: clearing transactional tables");
      await Promise.all([
        supabase.from("outstanding_balances").delete().eq("company_id", companyId),
        supabase.from("daybook").delete().eq("company_id", companyId),
        supabase.from("voucher_entries").delete().eq("company_id", companyId),
        supabase.from("sales_vouchers").delete().eq("company_id", companyId),
        supabase.from("purchase_vouchers").delete().eq("company_id", companyId),
        supabase.from("receipt_vouchers").delete().eq("company_id", companyId),
        supabase.from("payment_vouchers").delete().eq("company_id", companyId),
        supabase.from("contra_vouchers").delete().eq("company_id", companyId),
        supabase.from("journal_vouchers").delete().eq("company_id", companyId),
        supabase.from("credit_notes").delete().eq("company_id", companyId),
        supabase.from("debit_notes").delete().eq("company_id", companyId),
      ]);
    }

    // ── 1. Ledger Groups ──────────────────────────────────────────────────────
    if (Array.isArray(r.ledger_groups) && r.ledger_groups.length) {
      const rows = r.ledger_groups
        .filter((g: any) => str(g.name))
        .map((g: any) => ({
          company_id: companyId,
          tally_guid: str(g.guid),
          name: str(g.name),
          parent_guid: str(g.parent_guid || g.parent),
          nature: str(g.nature),
        }));
      await bulkUpsert(supabase, "ledger_groups", rows, "company_id,name", stats, errors, log);
    }

    // ── 2. Ledgers ────────────────────────────────────────────────────────────
    if (Array.isArray(r.ledgers) && r.ledgers.length) {
      const rows = r.ledgers
        .filter((l: any) => str(l.name)) // skip ledgers without a name — can't upsert without unique key
        .map((l: any) => {
          const groupName = str(l.group || l.parent);
          return {
            company_id: companyId,
            tally_guid: str(l.guid),
            name: str(l.name),
            group_name: groupName,
            opening_balance: num(l.opening_balance),
            closing_balance: (num(l.closing_balance) !== 0) ? num(l.closing_balance) : null,
            is_customer: !!l.is_customer || /sundry debtors|receivable/i.test(groupName || ""),
            is_supplier: !!l.is_supplier || /sundry creditors|payable/i.test(groupName || ""),
            is_bank: !!l.is_bank || /bank/i.test(groupName || ""),
            is_cash: !!l.is_cash || /^cash(-in-hand)?$/i.test(groupName || ""),
            gst_number: str(l.gst_number || l.gst),
            phone: str(l.phone),
            address: str(l.address),
          };
        });
      log(`Ledgers: ${r.ledgers.length} received, ${rows.length} with valid names`);
      await bulkUpsert(supabase, "ledgers", rows, "company_id,name", stats, errors, log);
    }

    // ── 3. Stock Groups ───────────────────────────────────────────────────────
    if (Array.isArray(r.stock_groups) && r.stock_groups.length) {
      const rows = r.stock_groups
        .filter((g: any) => str(g.name))
        .map((g: any) => ({
          company_id: companyId, tally_guid: str(g.guid),
          name: str(g.name), parent_guid: str(g.parent),
        }));
      await bulkUpsert(supabase, "stock_groups", rows, "company_id,name", stats, errors, log);
    }

    // ── 4. Units ──────────────────────────────────────────────────────────────
    if (Array.isArray(r.units) && r.units.length) {
      const rows = r.units
        .filter((u: any) => str(u.name))
        .map((u: any) => ({
          company_id: companyId, tally_guid: str(u.guid),
          name: str(u.name), symbol: str(u.symbol || u.name),
        }));
      await bulkUpsert(supabase, "units", rows, "company_id,name", stats, errors, log);
    }

    // ── 5. Godowns ────────────────────────────────────────────────────────────
    if (Array.isArray(r.godowns) && r.godowns.length) {
      const rows = r.godowns
        .filter((g: any) => str(g.name))
        .map((g: any) => ({
          company_id: companyId, tally_guid: str(g.guid), name: str(g.name),
        }));
      await bulkUpsert(supabase, "godowns", rows, "company_id,name", stats, errors, log);
    }

    // ── 6. Stock Items ────────────────────────────────────────────────────────
    if (Array.isArray(r.stock_items) && r.stock_items.length) {
      const rows = r.stock_items
        .filter((s: any) => str(s.name)) // skip stock items without a name
        .map((s: any) => ({
          company_id: companyId,
          tally_guid: str(s.guid),
          name: str(s.name),
          opening_stock: num(s.opening_stock),
          opening_value: num(s.opening_value),
          rate: num(s.rate),
          current_stock: num(s.current_stock ?? s.opening_stock),
          current_value: num(s.current_value ?? s.opening_value),
        }));
      log(`Stock items: ${r.stock_items.length} received, ${rows.length} with valid names`);
      await bulkUpsert(supabase, "stock_items", rows, "company_id,name", stats, errors, log);
    }

    // ── 7. Derive Customers / Suppliers / Bank / Cash from ledger flags ───────
    // One query to get all flagged ledgers, then bulk upsert each group.
    const { data: allLedgers } = await supabase.from("ledgers")
      .select("id, name, opening_balance, closing_balance, gst_number, phone, address, is_customer, is_supplier, is_bank, is_cash")
      .eq("company_id", companyId);

    if (allLedgers) {
      const customers = allLedgers.filter((l:any) => l.is_customer).map((l:any) => ({
        company_id: companyId, ledger_id: l.id, name: l.name,
        gst_number: l.gst_number, phone: l.phone, address: l.address,
        opening_balance: l.opening_balance, closing_balance: l.closing_balance,
      }));
      if (customers.length) await bulkUpsert(supabase, "customers", customers, "company_id,name", stats, errors, log);

      const suppliers = allLedgers.filter((l:any) => l.is_supplier).map((l:any) => ({
        company_id: companyId, ledger_id: l.id, name: l.name,
        gst_number: l.gst_number, phone: l.phone, address: l.address,
        opening_balance: l.opening_balance, closing_balance: l.closing_balance,
      }));
      if (suppliers.length) await bulkUpsert(supabase, "suppliers", suppliers, "company_id,name", stats, errors, log);

      const banks = allLedgers.filter((l:any) => l.is_bank).map((l:any) => ({
        company_id: companyId, ledger_id: l.id, name: l.name,
        opening_balance: l.opening_balance, current_balance: l.closing_balance,
      }));
      if (banks.length) await bulkUpsert(supabase, "bank_accounts", banks, "company_id,name", stats, errors, log);

      const cashAccs = allLedgers.filter((l:any) => l.is_cash).map((l:any) => ({
        company_id: companyId, ledger_id: l.id, name: l.name,
        opening_balance: l.opening_balance, current_balance: l.closing_balance,
      }));
      if (cashAccs.length) await bulkUpsert(supabase, "cash_accounts", cashAccs, "company_id,name", stats, errors, log);
    }

    // ── 8. Outstanding Balances ───────────────────────────────────────────────
    // Use real bill-wise outstanding if provided by agent, otherwise derive from ledger closing balances.
    if (Array.isArray(r.outstanding_balances) && r.outstanding_balances.length > 0) {
      const ledgerIdMap = buildNameIdMap(allLedgers || []);
      const today = new Date().toISOString().slice(0,10);
      const rows = r.outstanding_balances
        .filter((o:any) => {
          const a = num(o.amount);
          return a !== 0 && str(o.ledger_name);
        })
        .map((o:any) => {
          const ledgerName = str(o.ledger_name)!;
          return {
            company_id: companyId,
            ledger_id: ledgerIdMap.get(ledgerName) || null,
            ledger_name: ledgerName,
            kind: (o.kind === "payable") ? "payable" : "receivable",
            amount: Math.abs(num(o.amount)),
            overdue_amount: num(o.overdue_amount),
            as_of_date: date(o.as_of_date) || today,
          };
        });
      if (rows.length) await bulkUpsert(supabase, "outstanding_balances", rows, "company_id,ledger_name,kind", stats, errors, log);
    } else if (allLedgers) {
      // Derive from ledger closing balances
      const today = new Date().toISOString().slice(0,10);
      const rows = allLedgers
        .filter((l:any) => (l.is_customer || l.is_supplier) && num(l.closing_balance) !== 0)
        .map((l:any) => ({
          company_id: companyId, ledger_id: l.id, ledger_name: l.name,
          kind: l.is_supplier ? "payable" : "receivable",
          amount: Math.abs(num(l.closing_balance)),
          overdue_amount: 0, as_of_date: today,
        }));
      if (rows.length) await bulkUpsert(supabase, "outstanding_balances", rows, "company_id,ledger_name,kind", stats, errors, log);
      log(`Outstanding: derived ${rows.length} from ledger closing balances`);
    }

    // ── 9. Build ledger name→id map for voucher entry linking ─────────────────
    // One bulk query, then Map lookups — no per-record queries.
    const ledgerIdMap = buildNameIdMap(allLedgers || []);

    // Also build stock item name→id map
    const { data: allStockItems } = await supabase.from("stock_items")
      .select("id, name").eq("company_id", companyId);
    const stockIdMap = buildNameIdMap(allStockItems || []);

    // ── 10. Vouchers ──────────────────────────────────────────────────────────
    const voucherTables = [
      { key: "sales_vouchers",    table: "sales_vouchers",    label: "Sales" },
      { key: "purchase_vouchers", table: "purchase_vouchers", label: "Purchase" },
      { key: "receipt_vouchers",  table: "receipt_vouchers",  label: "Receipt" },
      { key: "payment_vouchers",  table: "payment_vouchers",  label: "Payment" },
      { key: "contra_vouchers",   table: "contra_vouchers",   label: "Contra" },
      { key: "journal_vouchers",  table: "journal_vouchers",  label: "Journal" },
      { key: "credit_notes",      table: "credit_notes",      label: "Credit Note" },
      { key: "debit_notes",       table: "debit_notes",       label: "Debit Note" },
    ];

    for (const { key, table, label } of voucherTables) {
      const vouchers = r[key];
      if (!Array.isArray(vouchers) || !vouchers.length) continue;

      const headers: any[] = [];
      const entries: any[] = [];

      for (let vi = 0; vi < vouchers.length; vi++) {
        const v = vouchers[vi];
        const vDate = date(v.voucher_date || v.date) || new Date().toISOString().slice(0,10);
        const vNumber = str(v.voucher_number || v.number) || `V${Date.now()}_${vi}`;
        const partyName = str(v.party_name || v.party);

        const header: any = {
          company_id: companyId,
          tally_guid: str(v.guid),
          voucher_number: vNumber,
          voucher_date: vDate,
          party_name: partyName,
          party_ledger_id: partyName ? (ledgerIdMap.get(partyName) || null) : null,
          narration: str(v.narration),
        };

        if (table === "sales_vouchers" || table === "purchase_vouchers") {
          header.taxable_amount = num(v.taxable_amount);
          header.cgst = num(v.cgst);
          header.sgst = num(v.sgst);
          header.igst = num(v.igst);
          header.total_amount = num(v.total_amount || v.amount);
        } else {
          header.amount = num(v.amount || v.total_amount);
        }

        headers.push(header);

        // Ledger entries (accounting lines)
        const lines: any[] = Array.isArray(v.entries || v.ledger_entries || v.lines)
          ? (v.entries || v.ledger_entries || v.lines) : [];
        for (const e of lines) {
          const lName = str(e.ledger_name || e.ledger);
          entries.push({
            company_id: companyId,
            voucher_type: label,
            voucher_number: vNumber,
            voucher_date: vDate,
            ledger_id: lName ? (ledgerIdMap.get(lName) || null) : null,
            ledger_name: lName,
            stock_item_id: null,
            godown_id: null,
            quantity: num(e.quantity) || null,
            rate: num(e.rate) || null,
            debit: num(e.debit),
            credit: num(e.credit),
            hsn: str(e.hsn),
            batch_name: str(e.batch_name),
            narration: str(e.narration),
          });
        }

        // Inventory entries (stock movement lines)
        const invLines: any[] = Array.isArray(v.inventory_entries) ? v.inventory_entries : [];
        for (const e of invLines) {
          const iName = str(e.stock_item || e.item);
          entries.push({
            company_id: companyId,
            voucher_type: label,
            voucher_number: vNumber,
            voucher_date: vDate,
            ledger_id: null,
            ledger_name: null,
            stock_item_id: iName ? (stockIdMap.get(iName) || null) : null,
            godown_id: null,
            quantity: num(e.quantity) || null,
            rate: num(e.rate) || null,
            debit: 0,
            credit: 0,
            hsn: str(e.hsn),
            batch_name: str(e.batch_name),
            narration: null,
          });
        }
      }

      await bulkUpsert(supabase, table, headers, "company_id,voucher_number", stats, errors, log);
      if (entries.length) {
        await bulkUpsert(supabase, "voucher_entries", entries,
          "company_id,voucher_type,voucher_number,ledger_name,voucher_date", stats, errors, log);
      }
    }

    // ── 11. Daybook ───────────────────────────────────────────────────────────
    if (Array.isArray(r.daybook) && r.daybook.length) {
      const today = new Date().toISOString().slice(0,10);
      const rows = r.daybook.map((d: any) => ({
        company_id: companyId,
        voucher_type: str(d.voucher_type) || "Journal",
        voucher_number: str(d.voucher_number) || "",
        voucher_date: date(d.voucher_date) || today,
        ledger_name: str(d.ledger_name) || "",
        debit: num(d.debit),
        credit: num(d.credit),
        narration: str(d.narration),
      }));
      await bulkUpsert(supabase, "daybook", rows,
        "company_id,voucher_number,voucher_type,ledger_name,voucher_date", stats, errors, log);
    }

    // ── 12. Refresh dashboard cache ───────────────────────────────────────────
    const { error: rpcErr } = await supabase.rpc("refresh_dashboard_cache", { p_company_id: companyId });
    if (rpcErr) errors.push(`refresh_dashboard_cache: ${rpcErr.message}`);

    // ── 13. Heartbeat + close sync log ────────────────────────────────────────
    const totalRecords = Object.values(stats).reduce((a,b)=>a+b, 0);
    const finishedAt = new Date();
    const durationMs = finishedAt.getTime() - startedAt.getTime();

    await supabase.from("heartbeat").upsert({
      id: 1, agent_connected: true,
      last_heartbeat: finishedAt.toISOString(),
      last_sync_at: finishedAt.toISOString(),
      current_company: payload.company_name,
      records_synced: totalRecords,
      errors: errors.length,
      last_error: errors[0] || null,
    }, { onConflict: "id" });

    await supabase.from("sync_logs").update({
      status: errors.length ? "partial" : "success",
      records_synced: totalRecords,
      errors: errors.length,
      error_detail: errors.length ? { errors: errors.slice(0, 50) } : null,
      finished_at: finishedAt.toISOString(),
      duration_ms: durationMs,
    }).eq("id", syncLog?.id);

    return new Response(JSON.stringify({
      success: true,
      company: payload.company_name,
      sync_type: payload.sync_type,
      records_synced: totalRecords,
      stats,
      errors: errors.slice(0, 50),
      duration_ms: durationMs,
    }), { headers: { ...corsHeaders, "Content-Type": "application/json" } });

  } catch (e) {
    errors.push(`fatal: ${e.message}`);
    const finishedAt = new Date();
    await supabase.from("sync_logs").update({
      status: "failed", errors: errors.length,
      error_detail: { errors: errors.slice(0, 50) },
      finished_at: finishedAt.toISOString(),
      duration_ms: finishedAt.getTime() - startedAt.getTime(),
    }).eq("id", syncLog?.id);
    await supabase.from("heartbeat").upsert({
      id: 1, agent_connected: true,
      last_heartbeat: new Date().toISOString(),
      last_error: e.message, errors: 1,
    }, { onConflict: "id" });
    return jsonError(500, "Sync failed: " + e.message);
  }
});

function buildNameIdMap(rows: any[]): Map<string, string> {
  const m = new Map<string, string>();
  for (const r of rows) {
    if (r.name && r.id) m.set(r.name, r.id);
  }
  return m;
}

function jsonError(status: number, message: string) {
  return new Response(JSON.stringify({ success: false, error: message }), {
    status, headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
