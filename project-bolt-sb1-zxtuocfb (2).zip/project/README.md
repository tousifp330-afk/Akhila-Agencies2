# Akhila ERP — Fertilizer Wholesale Management

A complete production-ready ERP system for a fertilizer wholesale agency. The ERP automatically synchronizes with **TallyPrime** — TallyPrime is the single source of truth. Whenever data changes in TallyPrime, the ERP updates automatically. No manual entry, no CSV, no Excel, no manual refresh.

## Architecture

```
TallyPrime (Windows, localhost:9000)
        ↓
Windows Sync Agent (Node.js + TypeScript)
        ↓
Supabase Edge Functions (sync-ingest, heartbeat, dashboard-refresh, sync-status)
        ↓
Supabase Database (PostgreSQL, normalized ERP schema)
        ↓
React ERP Dashboard (this app)
```

## Tech Stack

- **Frontend**: React + TypeScript + Vite + TailwindCSS + lucide-react
- **Backend**: Supabase (PostgreSQL, Auth, Realtime, Edge Functions)
- **Sync Agent**: Node.js 20+ + TypeScript (Windows background service)

## Supported Companies

1. `M/s Akhila Agencies - (from 1-Apr-23) - (from 1-Apr-24) - (from 1-Apr-25)`
2. `M/s R.Vithoba Setty & Sons`

The active company is detected automatically from TallyPrime.

## Project Structure

```
project/
├── src/                          # React ERP frontend
│   ├── App.tsx                   # Root + routing
│   ├── lib/
│   │   ├── supabase.ts           # Supabase client singleton
│   │   ├── auth.tsx              # Auth context (sign-in / sign-up / roles)
│   │   ├── company.tsx           # Active company context
│   │   ├── router.tsx            # Hash router
│   │   ├── types.ts              # TypeScript types for all ERP entities
│   │   └── format.ts             # Currency / date / number formatters
│   ├── components/
│   │   ├── Layout.tsx            # Sidebar + topbar shell
│   │   └── ui.tsx                # Reusable UI primitives
│   └── pages/
│       ├── Auth.tsx              # Sign in / sign up
│       ├── Dashboard.tsx
│       ├── Daybook.tsx
│       ├── Ledgers.tsx
│       ├── Customers.tsx
│       ├── Suppliers.tsx
│       ├── StockSummary.tsx
│       ├── Sales.tsx
│       ├── Purchases.tsx
│       ├── Bank.tsx
│       ├── Cash.tsx
│       ├── Outstanding.tsx
│       ├── Reports.tsx
│       ├── Users.tsx
│       ├── AuditLogs.tsx
│       ├── SyncStatus.tsx
│       └── Settings.tsx
├── supabase/
│   └── functions/
│       ├── sync-ingest/          # Receives + validates + upserts sync payloads
│       ├── heartbeat/           # Agent heartbeat
│       ├── dashboard-refresh/   # Recomputes dashboard cache
│       └── sync-status/         # Returns heartbeat + recent sync logs
├── sync-agent/                   # Windows Sync Agent (Node.js + TS)
│   ├── src/
│   │   ├── index.ts              # Entry point (timers, heartbeat, tray)
│   │   ├── config.ts             # Config + state load/save
│   │   ├── logger.ts             # Winston logger
│   │   ├── tally.ts               # Tally XML API client
│   │   ├── transform.ts          # Raw Tally → normalized records
│   │   ├── sync.ts                # Full + incremental sync orchestration
│   │   ├── uploader.ts            # Posts to Supabase Edge Functions
│   │   ├── tray.ts                # System tray (optional)
│   │   └── autostart.ts           # HKCU Run registration
│   ├── installer/
│   │   ├── installer.nsi          # NSIS installer script
│   │   └── build.ps1              # PowerShell build script
│   ├── config.example.json
│   └── README.md
└── README.md                     # This file
```

## Database Schema

The normalized schema is applied via two Supabase migrations:

1. **`0001_erp_core_schema`** — All tables, indexes, triggers, RLS policies, and the auto-profile trigger on `auth.users`.
2. **`0002_refresh_dashboard_cache`** — `refresh_dashboard_cache(p_company_id)` PL/pgSQL function.

### Tables

**Auth / Access**: `companies`, `users`, `roles`, `permissions`, `role_permissions`, `user_roles`, `audit_logs`

**Master Data**: `ledger_groups`, `ledgers`, `customers`, `suppliers`, `stock_groups`, `stock_items`, `godowns`, `units`, `batches`, `gst_rates`, `bank_accounts`, `cash_accounts`

**Vouchers**: `voucher_types`, `sales_vouchers`, `purchase_vouchers`, `receipt_vouchers`, `payment_vouchers`, `contra_vouchers`, `journal_vouchers`, `credit_notes`, `debit_notes`, `voucher_entries`

**Daybook**: `daybook` (flat indexed view)

**Balances & Caches**: `outstanding_balances`, `dashboard_cache`

**Sync**: `sync_logs`, `heartbeat`, `settings`, `raw_sync_payloads`

### RLS

- All tables have RLS enabled.
- ERP data tables: authenticated users can read/write (single agency, shared data).
- `users`, `user_roles`, `settings`: admin-only writes (enforced via `is_admin()` helper).
- `audit_logs`: insert by any authenticated; no update/delete.

## Edge Functions

| Function | Method | Purpose |
| --- | --- | --- |
| `sync-ingest` | POST | Validates payload, splits into per-entity upserts, updates `sync_logs` + `heartbeat`, refreshes dashboard cache |
| `heartbeat` | POST | Updates the single-row `heartbeat` table |
| `dashboard-refresh` | GET | Recomputes and returns dashboard cache for a company |
| `sync-status` | GET | Returns heartbeat + recent sync logs |

## Dashboard

The dashboard reads only from Supabase (the `dashboard_cache` table). It shows:

- Outstanding Receivables / Payables
- Bank Balance / Cash Balance
- Current Stock Value
- Top Debtors / Top Creditors
- Sales / Purchases totals
- Net Cash Flow
- Recent Activity (last 20 vouchers)

## Pages

Dashboard, Daybook, Ledgers, Customers, Suppliers, Stock Summary, Purchases, Sales, Bank, Cash, Outstanding, Reports, Users, Audit Logs, Sync Status, Settings.

## Sync Status Page

Displays: Agent Connected, Last Heartbeat, Current Company, Current Endpoint, Last Sync, Records Synced, Errors, Duration, plus a list of recent sync logs.

## Security

- Supabase Auth (email/password) — sign-up + sign-in built in
- Role-based access (admin, manager, accountant, viewer)
- Audit logging table (append-only)
- Edge functions validate every payload and reject unsupported companies
- Tally is never exposed to the Internet — the agent reads `localhost:9000` and pushes to Supabase

## Performance

- Batch upserts via `ON CONFLICT` constraints
- Realtime updates via Supabase Realtime (Sync Status page subscribes to `heartbeat` changes)
- Composite indexes on `(company_id, voucher_date)` for all voucher tables
- Materialized `dashboard_cache` recomputed after every sync
- Pagination via `.limit()` on heavy queries

## Getting Started

### 1. Deploy the web app

```bash
npm install
npm run build
```

The dev server runs automatically in the Bolt environment. For production, deploy the `dist/` folder to any static host (Vercel, Netlify, Cloudflare Pages).

### 2. Configure Supabase

The Supabase project is already provisioned. The migrations in this repo are applied automatically via the Supabase MCP `apply_migration` tool. To re-apply or inspect, use the Supabase dashboard.

### 3. Install the Windows Sync Agent

See [`sync-agent/README.md`](./sync-agent/README.md) for full instructions. In short:

1. On the Windows computer where TallyPrime is installed, run the installer (`sync-agent/installer/AkhilaERPSyncAgent-Setup.exe`).
2. Edit `config.json` with your Supabase URL and anon key.
3. Launch the agent. It will start a full sync immediately and continue with incremental syncs every minute.

### 4. Sign in to the ERP

Open the web app, create an account (the first account should be promoted to admin via the `user_roles` table — or use the Users page once an admin exists), and explore the dashboard.

## Deployment Guide

### Web app

- Build with `npm run build`. Output is in `dist/`.
- Deploy `dist/` to any static host. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` as build-time env vars (already in `.env`).

### Supabase

- Already provisioned. Migrations applied. Edge functions deployed.
- To redeploy an edge function: write the source under `supabase/functions/<name>/index.ts` and use the Supabase MCP `deploy_edge_function` tool.

### Windows Sync Agent

- Build with `installer/build.ps1` (requires Node.js 20+ and NSIS).
- Distribute `AkhilaERPSyncAgent-Setup.exe` to the agency's Windows machine.
- The agent registers itself to start with Windows (HKCU Run key).

## License

Internal use only — Akhila Agencies.
