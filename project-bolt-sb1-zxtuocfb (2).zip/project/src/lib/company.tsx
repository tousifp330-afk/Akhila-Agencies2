import { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { supabase } from './supabase';
import type { Company } from './types';

const CompanyContext = createContext<{
  companies: Company[];
  activeCompany: Company | null;
  setActiveCompanyId: (id: string) => void;
  loading: boolean;
} | undefined>(undefined);

const STORAGE_KEY = 'erp.active_company_id';

export function CompanyProvider({ children }: { children: ReactNode }) {
  const [companies, setCompanies] = useState<Company[]>([]);
  const [activeCompany, setActiveCompany] = useState<Company | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('companies').select('*').order('name').then(({ data }) => {
      const list = (data || []) as Company[];
      setCompanies(list);
      const stored = localStorage.getItem(STORAGE_KEY);
      const initial = list.find(c => c.id === stored) || list[0] || null;
      setActiveCompany(initial);
      setLoading(false);
    });
  }, []);

  function setActiveCompanyId(id: string) {
    const c = companies.find(c => c.id === id) || null;
    setActiveCompany(c);
    if (c) localStorage.setItem(STORAGE_KEY, c.id);
  }

  return (
    <CompanyContext.Provider value={{ companies, activeCompany, setActiveCompanyId, loading }}>
      {children}
    </CompanyContext.Provider>
  );
}

export function useCompany() {
  const ctx = useContext(CompanyContext);
  if (!ctx) throw new Error('useCompany must be used within CompanyProvider');
  return ctx;
}
