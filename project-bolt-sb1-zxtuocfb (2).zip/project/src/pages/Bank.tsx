import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useCompany } from '../lib/company';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, StatCard } from '../components/ui';
import { formatCurrency } from '../lib/format';
import type { BankAccount } from '../lib/types';
import { Landmark } from 'lucide-react';

export function BankPage() {
  const { activeCompany } = useCompany();
  const [rows, setRows] = useState<BankAccount[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!activeCompany) return;
    setLoading(true);
    supabase.from('bank_accounts').select('*').eq('company_id', activeCompany.id).order('name')
      .then(({ data }) => { setRows((data || []) as BankAccount[]); setLoading(false); });
  }, [activeCompany]);

  const total = rows.reduce((s, r) => s + Number(r.current_balance ?? r.opening_balance), 0);

  if (!activeCompany) return <Spinner />;

  return (
    <div>
      <PageHeader title="Bank Accounts" subtitle={activeCompany.name} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <StatCard label="Total Bank Balance" value={formatCurrency(total)} icon={Landmark} accent="blue" />
        <StatCard label="Account Count" value={String(rows.length)} icon={Landmark} accent="slate" />
      </div>
      <Card>
        {loading ? <Spinner /> : rows.length === 0 ? <EmptyState message="No bank accounts" /> : (
          <Table headers={['Bank', 'Account #', 'IFSC', 'Branch', 'Opening', 'Current']}>
            {rows.map(b => (
              <Tr key={b.id}>
                <Td className="font-medium">{b.name}</Td>
                <Td className="font-mono text-xs">{b.account_number || '—'}</Td>
                <Td className="font-mono text-xs">{b.ifsc || '—'}</Td>
                <Td>{b.branch || '—'}</Td>
                <Td className="text-right">{formatCurrency(b.opening_balance)}</Td>
                <Td className="text-right font-medium">{formatCurrency(b.current_balance)}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
