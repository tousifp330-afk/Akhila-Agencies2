import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useCompany } from '../lib/company';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, Input, StatCard } from '../components/ui';
import { formatCurrency, formatDate } from '../lib/format';
import type { PurchaseVoucher } from '../lib/types';
import { TrendingDown, ShoppingCart, IndianRupee } from 'lucide-react';

export function PurchasesPage() {
  const { activeCompany } = useCompany();
  const [rows, setRows] = useState<PurchaseVoucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!activeCompany) return;
    setLoading(true);
    supabase.from('purchase_vouchers').select('*').eq('company_id', activeCompany.id).order('voucher_date', { ascending: false }).limit(500)
      .then(({ data }) => { setRows((data || []) as PurchaseVoucher[]); setLoading(false); });
  }, [activeCompany]);

  const filtered = rows.filter(r => !search || r.voucher_number.toLowerCase().includes(search.toLowerCase()) || (r.party_name || '').toLowerCase().includes(search.toLowerCase()));
  const totalPurchases = rows.reduce((s, r) => s + Number(r.total_amount), 0);
  const totalGST = rows.reduce((s, r) => s + Number(r.cgst) + Number(r.sgst) + Number(r.igst), 0);

  if (!activeCompany) return <Spinner />;

  return (
    <div>
      <PageHeader title="Purchases" subtitle={`${activeCompany.name} · ${rows.length} vouchers`} />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard label="Total Purchases" value={formatCurrency(totalPurchases)} icon={TrendingDown} accent="amber" />
        <StatCard label="Voucher Count" value={String(rows.length)} icon={ShoppingCart} accent="blue" />
        <StatCard label="Total GST" value={formatCurrency(totalGST)} icon={IndianRupee} accent="slate" />
      </div>
      <Card className="p-4 mb-4">
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by voucher or party" />
      </Card>
      <Card>
        {loading ? <Spinner /> : filtered.length === 0 ? <EmptyState message="No purchase vouchers" /> : (
          <Table headers={['Date', 'Voucher #', 'Party', 'Taxable', 'GST', 'Total']}>
            {filtered.map(v => (
              <Tr key={v.id}>
                <Td className="whitespace-nowrap">{formatDate(v.voucher_date)}</Td>
                <Td className="font-mono text-xs">{v.voucher_number}</Td>
                <Td>{v.party_name || '—'}</Td>
                <Td className="text-right">{formatCurrency(v.taxable_amount)}</Td>
                <Td className="text-right">{formatCurrency(Number(v.cgst) + Number(v.sgst) + Number(v.igst))}</Td>
                <Td className="text-right font-medium">{formatCurrency(v.total_amount)}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
