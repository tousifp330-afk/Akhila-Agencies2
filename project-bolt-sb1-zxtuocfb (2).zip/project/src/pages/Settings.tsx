import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Card, PageHeader, Spinner, Button, Input, Badge } from '../components/ui';
import { RefreshCw, AlertTriangle, CheckCircle } from 'lucide-react';

export function SettingsPage() {
  const [settings, setSettings] = useState<Record<string, any>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [forceSyncing, setForceSyncing] = useState(false);
  const [forceSyncMsg, setForceSyncMsg] = useState<string | null>(null);

  useEffect(() => {
    supabase.from('settings').select('*').then(({ data }) => {
      const map: Record<string, any> = {};
      (data || []).forEach(s => { map[s.key] = s.value?.value ?? s.value; });
      setSettings(map);
      setLoading(false);
    });
  }, []);

  async function save() {
    setSaving(true);
    const updates = Object.entries(settings).map(([key, value]) =>
      supabase.from('settings').upsert({ key, value: { value } }, { onConflict: 'key' })
    );
    await Promise.all(updates);
    setSaving(false);
    setMessage('Settings saved.');
    setTimeout(() => setMessage(null), 2500);
  }

  async function forceFullSync() {
    setForceSyncing(true);
    setForceSyncMsg(null);
    const { error } = await supabase
      .from('settings')
      .upsert({ key: 'force_full_sync', value: { value: true, requested_at: new Date().toISOString() } }, { onConflict: 'key' });
    if (error) {
      setForceSyncMsg('Failed to trigger sync. Please try again.');
    } else {
      setForceSyncMsg('Full sync requested. The agent will pick this up within 60 seconds and re-download all masters and current-year vouchers.');
    }
    setForceSyncing(false);
    setTimeout(() => setForceSyncMsg(null), 6000);
  }

  if (loading) return <Spinner />;

  return (
    <div>
      <PageHeader title="Settings" subtitle="ERP and sync configuration" action={<Button onClick={save} disabled={saving}>{saving ? 'Saving...' : 'Save'}</Button>} />
      {message && <div className="mb-4 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-lg px-3 py-2">{message}</div>}
      <Card className="p-5 space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Tally Endpoint</label>
          <Input value={settings.tally_endpoint || ''} onChange={e => setSettings(s => ({ ...s, tally_endpoint: e.target.value }))} />
          <p className="text-xs text-slate-400 mt-1">The TallyPrime XML API endpoint. Default: http://localhost:9000</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Sync Interval (ms)</label>
          <Input type="number" value={settings.sync_interval_ms ?? 60000} onChange={e => setSettings(s => ({ ...s, sync_interval_ms: Number(e.target.value) }))} />
        </div>
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Heartbeat Interval (ms)</label>
          <Input type="number" value={settings.heartbeat_interval_ms ?? 30000} onChange={e => setSettings(s => ({ ...s, heartbeat_interval_ms: Number(e.target.value) }))} />
        </div>
        <div className="pt-4 border-t border-slate-100">
          <h3 className="font-semibold text-slate-900 mb-2">Supported Companies</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-2"><Badge color="emerald">Active</Badge> M/s Akhila Agencies - (from 1-Apr-23) - (from 1-Apr-24) - (from 1-Apr-25)</div>
            <div className="flex items-center gap-2"><Badge color="emerald">Active</Badge> M/s R.Vithoba Setty & Sons</div>
          </div>
        </div>
      </Card>

      <Card className="p-5 mt-4">
        <h3 className="font-semibold text-slate-900 mb-1">Force Full Sync</h3>
        <p className="text-sm text-slate-500 mb-4">
          Re-downloads all masters and current financial year vouchers from Tally.
          Use this if data appears missing or after major changes in Tally.
          The agent runs in incremental mode by default — this is the only way to trigger a complete refresh.
        </p>
        <Button onClick={forceFullSync} disabled={forceSyncing}>
          {forceSyncing ? 'Requesting...' : 'Force Full Sync'}
        </Button>
        {forceSyncMsg && (
          <div className={`mt-3 flex items-start gap-2 text-sm ${forceSyncMsg.includes('Failed') ? 'text-amber-700 bg-amber-50 border-amber-200' : 'text-emerald-700 bg-emerald-50 border-emerald-200'} border rounded-lg px-3 py-2`}>
            {forceSyncMsg.includes('Failed') ? <AlertTriangle size={16} className="mt-0.5 shrink-0" /> : <CheckCircle size={16} className="mt-0.5 shrink-0" />}
            <span>{forceSyncMsg}</span>
          </div>
        )}
      </Card>
    </div>
  );
}
