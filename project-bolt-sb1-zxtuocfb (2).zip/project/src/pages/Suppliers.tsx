import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useCompany } from '../lib/company';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, Input } from '../components/ui';
import { formatCurrency } from '../lib/format';
import type { Supplier } from '../lib/types';

export function SuppliersPage() {
  const { activeCompany } = useCompany();
  const [rows, setRows] = useState<Supplier[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!activeCompany) return;
    setLoading(true);
    supabase.from('suppliers').select('*').eq('company_id', activeCompany.id).order('name')
      .then(({ data }) => { setRows((data || []) as Supplier[]); setLoading(false); });
  }, [activeCompany]);

  const filtered = rows.filter(r => !search || r.name.toLowerCase().includes(search.toLowerCase()));

  if (!activeCompany) return <Spinner />;

  return (
    <div>
      <PageHeader title="Suppliers" subtitle={`${activeCompany.name} · ${rows.length} suppliers`} />
      <Card className="p-4 mb-4">
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search suppliers" />
      </Card>
      <Card>
        {loading ? <Spinner /> : filtered.length === 0 ? <EmptyState message="No suppliers" /> : (
          <Table headers={['Name', 'GST', 'Phone', 'Opening', 'Closing']}>
            {filtered.map(s => (
              <Tr key={s.id}>
                <Td className="font-medium">{s.name}</Td>
                <Td className="font-mono text-xs">{s.gst_number || '—'}</Td>
                <Td>{s.phone || '—'}</Td>
                <Td className="text-right">{formatCurrency(s.opening_balance)}</Td>
                <Td className="text-right">{formatCurrency(s.closing_balance)}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
