import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, Badge, StatCard, Button } from '../components/ui';
import { formatDateTime, timeAgo } from '../lib/format';
import type { Heartbeat, SyncLog } from '../lib/types';
import { Activity, CheckCircle2, AlertTriangle, XCircle, RefreshCw, Radio } from 'lucide-react';

export function SyncStatusPage() {
  const [heartbeat, setHeartbeat] = useState<Heartbeat | null>(null);
  const [logs, setLogs] = useState<SyncLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  async function load() {
    setRefreshing(true);
    const [hb, lg] = await Promise.all([
      supabase.from('heartbeat').select('*').eq('id', 1).maybeSingle(),
      supabase.from('sync_logs').select('*').order('started_at', { ascending: false }).limit(50),
    ]);
    setHeartbeat(hb.data as Heartbeat | null);
    setLogs((lg.data || []) as SyncLog[]);
    setLoading(false);
    setRefreshing(false);
  }

  useEffect(() => {
    load();
    const sub = supabase.channel('sync-status').on('postgres_changes', { event: '*', schema: 'public', table: 'heartbeat' }, load).subscribe();
    return () => { supabase.removeChannel(sub); };
  }, []);

  if (loading) return <Spinner />;

  const isOnline = heartbeat?.agent_connected && heartbeat?.last_heartbeat &&
    (Date.now() - new Date(heartbeat.last_heartbeat).getTime()) < 90_000;

  return (
    <div>
      <PageHeader
        title="Sync Status"
        subtitle="Live status of the Windows Sync Agent"
        action={<Button variant="secondary" size="sm" onClick={load}><RefreshCw className={`w-4 h-4 mr-1 ${refreshing ? 'animate-spin' : ''}`} />Refresh</Button>}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          label="Agent Status"
          value={isOnline ? 'Online' : 'Offline'}
          icon={isOnline ? Radio : XCircle}
          accent={isOnline ? 'emerald' : 'rose'}
          hint={isOnline ? `last beat ${timeAgo(heartbeat?.last_heartbeat)}` : 'not connected'}
        />
        <StatCard label="Last Sync" value={timeAgo(heartbeat?.last_sync_at)} icon={CheckCircle2} accent="blue" hint={heartbeat?.last_sync_at ? formatDateTime(heartbeat.last_sync_at) : 'never'} />
        <StatCard label="Records Synced" value={String(heartbeat?.records_synced ?? 0)} icon={Activity} accent="slate" />
        <StatCard label="Errors" value={String(heartbeat?.errors ?? 0)} icon={AlertTriangle} accent={heartbeat?.errors ? 'rose' : 'slate'} hint={heartbeat?.last_error || undefined} />
      </div>

      <Card className="p-5 mb-6">
        <h3 className="font-semibold text-slate-900 mb-4">Agent Details</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
          <Detail label="Agent Connected" value={heartbeat?.agent_connected ? <Badge color="emerald">Yes</Badge> : <Badge color="red">No</Badge>} />
          <Detail label="Last Heartbeat" value={formatDateTime(heartbeat?.last_heartbeat)} />
          <Detail label="Current Company" value={heartbeat?.current_company || '—'} />
          <Detail label="Current Endpoint" value={heartbeat?.current_endpoint || '—'} />
          <Detail label="Last Sync At" value={formatDateTime(heartbeat?.last_sync_at)} />
          <Detail label="Last Error" value={heartbeat?.last_error || '—'} />
        </div>
      </Card>

      <Card>
        <h3 className="font-semibold text-slate-900 p-5 border-b border-slate-100">Sync Logs</h3>
        {logs.length === 0 ? <EmptyState message="No sync runs yet" /> : (
          <Table headers={['Started', 'Type', 'Status', 'Records', 'Errors', 'Duration']}>
            {logs.map(l => (
              <Tr key={l.id}>
                <Td className="whitespace-nowrap">{formatDateTime(l.started_at)}</Td>
                <Td><Badge>{l.sync_type}</Badge></Td>
                <Td>
                  <Badge color={l.status === 'success' ? 'emerald' : l.status === 'partial' ? 'amber' : l.status === 'failed' ? 'red' : 'slate'}>
                    {l.status}
                  </Badge>
                </Td>
                <Td>{l.records_synced}</Td>
                <Td>{l.errors}</Td>
                <Td>{l.duration_ms ? `${(l.duration_ms / 1000).toFixed(1)}s` : '—'}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}

function Detail({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">{label}</div>
      <div className="mt-1 text-slate-800">{value}</div>
    </div>
  );
}
