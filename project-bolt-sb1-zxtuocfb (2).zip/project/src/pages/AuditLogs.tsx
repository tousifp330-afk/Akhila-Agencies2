import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, Badge } from '../components/ui';
import { formatDateTime } from '../lib/format';
import type { AuditLog } from '../lib/types';

export function AuditLogsPage() {
  const [rows, setRows] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    supabase.from('audit_logs').select('*').order('created_at', { ascending: false }).limit(500)
      .then(({ data }) => { setRows((data || []) as AuditLog[]); setLoading(false); });
  }, []);

  return (
    <div>
      <PageHeader title="Audit Logs" subtitle="Append-only trail of user actions" />
      <Card>
        {loading ? <Spinner /> : rows.length === 0 ? <EmptyState message="No audit entries yet" /> : (
          <Table headers={['When', 'Action', 'Entity', 'Detail']}>
            {rows.map(a => (
              <Tr key={a.id}>
                <Td className="whitespace-nowrap">{formatDateTime(a.created_at)}</Td>
                <Td><Badge>{a.action}</Badge></Td>
                <Td className="font-mono text-xs">{a.entity || '—'}{a.entity_id ? `:${a.entity_id.slice(0,8)}` : ''}</Td>
                <Td className="text-slate-500 text-xs">{a.detail ? JSON.stringify(a.detail) : '—'}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
