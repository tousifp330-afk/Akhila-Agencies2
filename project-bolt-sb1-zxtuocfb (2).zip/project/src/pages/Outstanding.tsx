import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useCompany } from '../lib/company';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, StatCard, Badge } from '../components/ui';
import { formatCurrency, formatDate } from '../lib/format';
import type { OutstandingBalance } from '../lib/types';
import { ArrowUpRight, ArrowDownRight, AlertCircle } from 'lucide-react';

export function OutstandingPage() {
  const { activeCompany } = useCompany();
  const [rows, setRows] = useState<OutstandingBalance[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!activeCompany) return;
    setLoading(true);
    supabase.from('outstanding_balances').select('*').eq('company_id', activeCompany.id).order('amount', { ascending: false })
      .then(({ data }) => { setRows((data || []) as OutstandingBalance[]); setLoading(false); });
  }, [activeCompany]);

  const receivables = rows.filter(r => r.kind === 'receivable');
  const payables = rows.filter(r => r.kind === 'payable');
  const totalRec = receivables.reduce((s, r) => s + Number(r.amount), 0);
  const totalPay = payables.reduce((s, r) => s + Number(r.amount), 0);
  const overdue = rows.reduce((s, r) => s + Number(r.overdue_amount), 0);

  if (!activeCompany) return <Spinner />;

  return (
    <div>
      <PageHeader title="Outstanding Balances" subtitle={activeCompany.name} />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard label="Receivables" value={formatCurrency(totalRec)} icon={ArrowUpRight} accent="emerald" />
        <StatCard label="Payables" value={formatCurrency(totalPay)} icon={ArrowDownRight} accent="rose" />
        <StatCard label="Overdue" value={formatCurrency(overdue)} icon={AlertCircle} accent="amber" />
      </div>

      <Card className="p-5 mb-6">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <ArrowUpRight className="w-4 h-4 text-emerald-600" /> Receivables ({receivables.length})
        </h3>
        {receivables.length === 0 ? <EmptyState message="No receivables" /> : (
          <Table headers={['Ledger', 'Amount', 'Overdue', 'As of']}>
            {receivables.map(r => (
              <Tr key={r.id}>
                <Td className="font-medium">{r.ledger_name}</Td>
                <Td className="text-right">{formatCurrency(r.amount)}</Td>
                <Td className="text-right">{r.overdue_amount ? <Badge color="red">{formatCurrency(r.overdue_amount)}</Badge> : '—'}</Td>
                <Td>{formatDate(r.as_of_date)}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>

      <Card className="p-5">
        <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
          <ArrowDownRight className="w-4 h-4 text-rose-600" /> Payables ({payables.length})
        </h3>
        {payables.length === 0 ? <EmptyState message="No payables" /> : (
          <Table headers={['Ledger', 'Amount', 'Overdue', 'As of']}>
            {payables.map(r => (
              <Tr key={r.id}>
                <Td className="font-medium">{r.ledger_name}</Td>
                <Td className="text-right">{formatCurrency(r.amount)}</Td>
                <Td className="text-right">{r.overdue_amount ? <Badge color="red">{formatCurrency(r.overdue_amount)}</Badge> : '—'}</Td>
                <Td>{formatDate(r.as_of_date)}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
