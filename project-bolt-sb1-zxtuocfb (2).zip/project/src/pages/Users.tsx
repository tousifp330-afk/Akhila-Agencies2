import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, Badge, Button, Select } from '../components/ui';
import { formatDate } from '../lib/format';
import { useAuth } from '../lib/auth';
import type { UserProfile, Role } from '../lib/types';

export function UsersPage() {
  const { profile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [userRoles, setUserRoles] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      supabase.from('users').select('*').order('created_at', { ascending: false }),
      supabase.from('roles').select('*'),
      supabase.from('user_roles').select('user_id, role_id'),
    ]).then(([u, r, ur]) => {
      setUsers((u.data || []) as UserProfile[]);
      setRoles((r.data || []) as Role[]);
      const map: Record<string, string> = {};
      (ur.data || []).forEach((x: any) => { map[x.user_id] = x.role_id; });
      setUserRoles(map);
      setLoading(false);
    });
  }, []);

  async function changeRole(userId: string, roleId: string) {
    const oldRoleId = userRoles[userId];
    if (oldRoleId === roleId) return;
    if (oldRoleId) {
      await supabase.from('user_roles').delete().eq('user_id', userId).eq('role_id', oldRoleId);
    }
    await supabase.from('user_roles').insert({ user_id: userId, role_id: roleId });
    setUserRoles(prev => ({ ...prev, [userId]: roleId }));
  }

  async function toggleActive(u: UserProfile) {
    await supabase.from('users').update({ is_active: !u.is_active }).eq('id', u.id);
    setUsers(prev => prev.map(x => x.id === u.id ? { ...x, is_active: !x.is_active } : x));
  }

  if (loading) return <Spinner />;

  return (
    <div>
      <PageHeader title="Users & Roles" subtitle="Manage ERP users and their access" />
      <Card>
        {users.length === 0 ? <EmptyState message="No users yet" /> : (
          <Table headers={['User', 'Email', 'Role', 'Status', 'Created', 'Actions']}>
            {users.map(u => (
              <Tr key={u.id}>
                <Td className="font-medium">{u.display_name || '—'}</Td>
                <Td>{u.email}</Td>
                <Td>
                  <Select value={userRoles[u.id] || ''} onChange={e => changeRole(u.id, e.target.value)} className="min-w-[140px]">
                    <option value="">— select —</option>
                    {roles.map(r => <option key={r.id} value={r.id}>{r.name}</option>)}
                  </Select>
                </Td>
                <Td>
                  {u.is_active ? <Badge color="emerald">Active</Badge> : <Badge color="red">Disabled</Badge>}
                </Td>
                <Td>{formatDate(u.created_at)}</Td>
                <Td>
                  <Button variant="ghost" size="sm" onClick={() => toggleActive(u)}>
                    {u.is_active ? 'Disable' : 'Enable'}
                  </Button>
                </Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
      {profile && (
        <p className="text-xs text-slate-400 mt-3">Signed in as {profile.email}. Only admins can manage users.</p>
      )}
    </div>
  );
}
