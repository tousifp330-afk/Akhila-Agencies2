import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useCompany } from '../lib/company';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, Input, Badge } from '../components/ui';
import { formatCurrency } from '../lib/format';
import type { Customer } from '../lib/types';

export function CustomersPage() {
  const { activeCompany } = useCompany();
  const [rows, setRows] = useState<Customer[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!activeCompany) return;
    setLoading(true);
    supabase.from('customers').select('*').eq('company_id', activeCompany.id).order('name')
      .then(({ data }) => { setRows((data || []) as Customer[]); setLoading(false); });
  }, [activeCompany]);

  const filtered = rows.filter(r => !search || r.name.toLowerCase().includes(search.toLowerCase()));

  if (!activeCompany) return <Spinner />;

  return (
    <div>
      <PageHeader title="Customers" subtitle={`${activeCompany.name} · ${rows.length} customers`} />
      <Card className="p-4 mb-4">
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search customers" />
      </Card>
      <Card>
        {loading ? <Spinner /> : filtered.length === 0 ? <EmptyState message="No customers" /> : (
          <Table headers={['Name', 'GST', 'Phone', 'Opening', 'Closing', 'Credit Limit']}>
            {filtered.map(c => (
              <Tr key={c.id}>
                <Td className="font-medium">{c.name}</Td>
                <Td className="font-mono text-xs">{c.gst_number || '—'}</Td>
                <Td>{c.phone || '—'}</Td>
                <Td className="text-right">{formatCurrency(c.opening_balance)}</Td>
                <Td className="text-right">{formatCurrency(c.closing_balance)}</Td>
                <Td className="text-right">{c.credit_limit ? formatCurrency(c.credit_limit) : <Badge>—</Badge>}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
