import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useCompany } from '../lib/company';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, Input, StatCard } from '../components/ui';
import { formatCurrency, formatDate } from '../lib/format';
import type { SalesVoucher } from '../lib/types';
import { TrendingUp, Receipt, IndianRupee } from 'lucide-react';

export function SalesPage() {
  const { activeCompany } = useCompany();
  const [rows, setRows] = useState<SalesVoucher[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    if (!activeCompany) return;
    setLoading(true);
    supabase.from('sales_vouchers').select('*').eq('company_id', activeCompany.id).order('voucher_date', { ascending: false }).limit(500)
      .then(({ data }) => { setRows((data || []) as SalesVoucher[]); setLoading(false); });
  }, [activeCompany]);

  const filtered = rows.filter(r => !search || r.voucher_number.toLowerCase().includes(search.toLowerCase()) || (r.party_name || '').toLowerCase().includes(search.toLowerCase()));
  const totalSales = rows.reduce((s, r) => s + Number(r.total_amount), 0);
  const totalGST = rows.reduce((s, r) => s + Number(r.cgst) + Number(r.sgst) + Number(r.igst), 0);

  if (!activeCompany) return <Spinner />;

  return (
    <div>
      <PageHeader title="Sales" subtitle={`${activeCompany.name} · ${rows.length} vouchers`} />
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard label="Total Sales" value={formatCurrency(totalSales)} icon={TrendingUp} accent="emerald" />
        <StatCard label="Voucher Count" value={String(rows.length)} icon={Receipt} accent="blue" />
        <StatCard label="Total GST" value={formatCurrency(totalGST)} icon={IndianRupee} accent="amber" />
      </div>
      <Card className="p-4 mb-4">
        <Input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by voucher or party" />
      </Card>
      <Card>
        {loading ? <Spinner /> : filtered.length === 0 ? <EmptyState message="No sales vouchers" /> : (
          <Table headers={['Date', 'Voucher #', 'Party', 'Taxable', 'GST', 'Total']}>
            {filtered.map(v => (
              <Tr key={v.id}>
                <Td className="whitespace-nowrap">{formatDate(v.voucher_date)}</Td>
                <Td className="font-mono text-xs">{v.voucher_number}</Td>
                <Td>{v.party_name || '—'}</Td>
                <Td className="text-right">{formatCurrency(v.taxable_amount)}</Td>
                <Td className="text-right">{formatCurrency(Number(v.cgst) + Number(v.sgst) + Number(v.igst))}</Td>
                <Td className="text-right font-medium">{formatCurrency(v.total_amount)}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
