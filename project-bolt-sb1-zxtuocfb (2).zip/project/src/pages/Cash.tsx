import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useCompany } from '../lib/company';
import { Card, PageHeader, Table, Td, Tr, Spinner, EmptyState, StatCard } from '../components/ui';
import { formatCurrency } from '../lib/format';
import type { CashAccount } from '../lib/types';
import { Banknote } from 'lucide-react';

export function CashPage() {
  const { activeCompany } = useCompany();
  const [rows, setRows] = useState<CashAccount[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!activeCompany) return;
    setLoading(true);
    supabase.from('cash_accounts').select('*').eq('company_id', activeCompany.id).order('name')
      .then(({ data }) => { setRows((data || []) as CashAccount[]); setLoading(false); });
  }, [activeCompany]);

  const total = rows.reduce((s, r) => s + Number(r.current_balance ?? r.opening_balance), 0);

  if (!activeCompany) return <Spinner />;

  return (
    <div>
      <PageHeader title="Cash Accounts" subtitle={activeCompany.name} />
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <StatCard label="Total Cash Balance" value={formatCurrency(total)} icon={Banknote} accent="amber" />
        <StatCard label="Account Count" value={String(rows.length)} icon={Banknote} accent="slate" />
      </div>
      <Card>
        {loading ? <Spinner /> : rows.length === 0 ? <EmptyState message="No cash accounts" /> : (
          <Table headers={['Name', 'Opening', 'Current']}>
            {rows.map(c => (
              <Tr key={c.id}>
                <Td className="font-medium">{c.name}</Td>
                <Td className="text-right">{formatCurrency(c.opening_balance)}</Td>
                <Td className="text-right font-medium">{formatCurrency(c.current_balance)}</Td>
              </Tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
}
