import { ReactNode, useState } from 'react';
import {
  LayoutDashboard, BookOpen, Wallet, Users, Truck, Package,
  ShoppingCart, TrendingUp, Landmark, Banknote, AlertCircle,
  FileBarChart, UserCog, ScrollText, RefreshCw, Settings,
  LogOut, Menu, X, Leaf, ChevronDown,
} from 'lucide-react';
import { useAuth } from '../lib/auth';
import { useCompany } from '../lib/company';
import { useRouter } from '../lib/router';

type NavItem = {
  to: string;
  label: string;
  icon: any;
  permission?: string;
};

const NAV: NavItem[] = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, permission: 'dashboard:view' },
  { to: '/daybook', label: 'Daybook', icon: BookOpen, permission: 'daybook:view' },
  { to: '/ledgers', label: 'Ledgers', icon: Wallet, permission: 'ledgers:view' },
  { to: '/customers', label: 'Customers', icon: Users, permission: 'customers:view' },
  { to: '/suppliers', label: 'Suppliers', icon: Truck, permission: 'suppliers:view' },
  { to: '/stock', label: 'Stock Summary', icon: Package, permission: 'stock:view' },
  { to: '/purchases', label: 'Purchases', icon: ShoppingCart, permission: 'purchases:view' },
  { to: '/sales', label: 'Sales', icon: TrendingUp, permission: 'sales:view' },
  { to: '/bank', label: 'Bank', icon: Landmark, permission: 'bank:view' },
  { to: '/cash', label: 'Cash', icon: Banknote, permission: 'cash:view' },
  { to: '/outstanding', label: 'Outstanding', icon: AlertCircle, permission: 'outstanding:view' },
  { to: '/reports', label: 'Reports', icon: FileBarChart, permission: 'reports:view' },
  { to: '/users', label: 'Users', icon: UserCog, permission: 'users:manage' },
  { to: '/audit', label: 'Audit Logs', icon: ScrollText, permission: 'audit:view' },
  { to: '/sync', label: 'Sync Status', icon: RefreshCw, permission: 'sync:view' },
  { to: '/settings', label: 'Settings', icon: Settings, permission: 'settings:manage' },
];

export function Layout({ children }: { children: ReactNode }) {
  const { path, navigate } = useRouter();
  const { profile, signOut, permissions } = useAuth();
  const { companies, activeCompany, setActiveCompanyId } = useCompany();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [companyMenuOpen, setCompanyMenuOpen] = useState(false);

  const visibleNav = NAV.filter(n => !n.permission || permissions.includes(n.permission) || permissions.includes('settings:manage'));

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-40 w-64 bg-slate-900 text-slate-100 flex flex-col transition-transform duration-300 ${mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="h-16 flex items-center gap-2 px-5 border-b border-slate-800">
          <div className="w-9 h-9 rounded-lg bg-emerald-500 flex items-center justify-center">
            <Leaf className="w-5 h-5 text-white" />
          </div>
          <div>
            <div className="font-semibold text-sm leading-tight">Akhila ERP</div>
            <div className="text-[10px] text-slate-400 uppercase tracking-wider">Fertilizer Wholesale</div>
          </div>
          <button className="ml-auto lg:hidden text-slate-400" onClick={() => setMobileOpen(false)}>
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
          {visibleNav.map(item => {
            const Icon = item.icon;
            const active = path === item.to || (item.to !== '/' && path.startsWith(item.to));
            return (
              <button
                key={item.to}
                onClick={() => { navigate(item.to); setMobileOpen(false); }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  active ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-300 hover:bg-slate-800 hover:text-white'
                }`}
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{item.label}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-800 p-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-emerald-700 flex items-center justify-center text-sm font-semibold">
              {profile?.display_name?.[0]?.toUpperCase() || profile?.email?.[0]?.toUpperCase() || 'U'}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium truncate">{profile?.display_name || 'User'}</div>
              <div className="text-xs text-slate-400 truncate">{profile?.email}</div>
            </div>
            <button onClick={signOut} className="text-slate-400 hover:text-white" title="Sign out">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {mobileOpen && <div className="fixed inset-0 bg-black/40 z-30 lg:hidden" onClick={() => setMobileOpen(false)} />}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center gap-4 px-4 lg:px-6 sticky top-0 z-20">
          <button className="lg:hidden text-slate-600" onClick={() => setMobileOpen(true)}>
            <Menu className="w-6 h-6" />
          </button>

          <div className="relative">
            <button
              onClick={() => setCompanyMenuOpen(o => !o)}
              className="flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-200 hover:bg-slate-50 text-sm font-medium text-slate-700"
            >
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              <span className="max-w-[260px] truncate">{activeCompany?.name || 'Select company'}</span>
              <ChevronDown className="w-4 h-4 text-slate-400" />
            </button>
            {companyMenuOpen && (
              <div className="absolute top-full mt-1 left-0 w-80 bg-white border border-slate-200 rounded-lg shadow-lg z-50">
                {companies.map(c => (
                  <button
                    key={c.id}
                    onClick={() => { setActiveCompanyId(c.id); setCompanyMenuOpen(false); }}
                    className={`w-full text-left px-4 py-3 text-sm hover:bg-slate-50 border-b border-slate-100 last:border-0 ${c.id === activeCompany?.id ? 'bg-emerald-50 text-emerald-800 font-medium' : 'text-slate-700'}`}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="ml-auto flex items-center gap-3">
            <SyncBadge />
          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6 overflow-x-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

function SyncBadge() {
  const { navigate } = useRouter();
  return (
    <button
      onClick={() => navigate('/sync')}
      className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-medium border border-emerald-200 hover:bg-emerald-100"
    >
      <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
      Sync
    </button>
  );
}
