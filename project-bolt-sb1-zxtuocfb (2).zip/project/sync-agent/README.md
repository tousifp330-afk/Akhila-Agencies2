# Akhila ERP Sync Agent

A Windows background service that synchronizes **TallyPrime** with the **Akhila ERP** web application via Supabase Edge Functions.

TallyPrime is the single source of truth. The agent reads Tally's XML API and pushes normalized records to Supabase, where the React dashboard reads them in real time.

## Architecture

```
TallyPrime (localhost:9000)
        ↓
Windows Sync Agent (this package)
        ↓
Supabase Edge Functions (sync-ingest, heartbeat)
        ↓
Supabase Database (PostgreSQL)
        ↓
React ERP Dashboard
```

## Requirements

- Windows 10 or 11 (64-bit)
- Node.js 20+
- TallyPrime with **Tally XML API** enabled on `localhost:9000`
  - In TallyPrime: **Gateway of Tally → F1 (Help) → Settings → Connectivity**
    - **Client/Server configuration**: `TallyPrime as Server` → **Yes**
    - **TallyPrime as Server Port**: `9000`

## Installation

### Option A — Use the installer

1. Run `AkhilaERPSyncAgent-Setup.exe` (built by `installer/build.ps1`).
2. Open the installed folder and edit `config.json`:
   ```json
   {
     "supabase_url": "https://YOUR_PROJECT.supabase.co",
     "supabase_anon_key": "YOUR_ANON_KEY",
     "tally_endpoint": "http://localhost:9000"
   }
   ```
3. Launch the agent from the Start Menu. It will register itself to start with Windows.

### Option B — Manual install

```powershell
cd sync-agent
npm install --omit=dev
npm run build
copy config.example.json config.json
# edit config.json
node dist\index.js
```

## Configuration

`config.json`:

| Key | Description | Default |
| --- | --- | --- |
| `supabase_url` | Your Supabase project URL | — |
| `supabase_anon_key` | Supabase anon public key | — |
| `tally_endpoint` | TallyPrime XML API URL | `http://localhost:9000` |
| `heartbeat_interval_ms` | Heartbeat cadence | `30000` |
| `sync_interval_ms` | Incremental sync cadence | `60000` |
| `full_sync_interval_ms` | Full sync cadence | `3600000` (1h) |
| `log_dir` | Log directory | `./logs` |
| `data_dir` | State directory | `./data` |
| `start_with_windows` | Register in HKCU Run | `true` |
| `system_tray` | Show system tray icon | `true` |
| `companies` | Companies to sync (must match Tally names exactly) | the two supported companies |

## Supported Companies

The agent only synchronizes these two companies (names must match Tally exactly):

1. `M/s Akhila Agencies - (from 1-Apr-23) - (from 1-Apr-24) - (from 1-Apr-25)`
2. `M/s R.Vithoba Setty & Sons`

## How sync works

- **First run**: a **full sync** reads all masters and vouchers from 1-Apr-2020 onward and uploads them.
- **Subsequent runs**: every `sync_interval_ms`, an **incremental sync** pulls vouchers since the last successful sync date.
- **Hourly**: a full sync refreshes everything to keep the dashboard cache consistent.
- **Heartbeat**: every 30s the agent pings the `heartbeat` edge function so the dashboard shows "Online".
- **Retry**: failed syncs log the error and increment the error counter; the next interval retries automatically.
- **State**: persisted in `data/sync-state.json` so the agent resumes after restarts.

## Logs

- `logs/agent.log` — all log levels
- `logs/error.log` — errors only
- Console output (colorized)

## Verifying

After the agent is running, open the ERP web app → **Sync Status** page. You should see:
- Agent: Online
- Last heartbeat: a few seconds ago
- Sync logs with `success` / `partial` / `failed` statuses
- Records synced counts

## Troubleshooting

- **"Tally returned HTTP error"** — TallyPrime is not running as a server. Re-enable connectivity settings.
- **"sync-ingest failed (401)"** — wrong Supabase URL or anon key in `config.json`.
- **"Unsupported company"** — the active Tally company name does not match the supported names exactly. Open TallyPrime, switch to one of the supported companies.
- **Dashboard shows "No dashboard data yet"** — the agent hasn't completed its first sync yet. Wait for the first sync log to show `success`.

## Uninstall

- Installer: run `uninstall.exe` in the install directory.
- Manual: stop the process, delete the folder, and remove the `AkhilaERPSyncAgent` entry from `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`.
