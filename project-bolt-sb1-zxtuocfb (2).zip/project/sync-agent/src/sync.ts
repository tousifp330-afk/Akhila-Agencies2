import { Logger } from 'winston';
import { TallyClient, tallyDate } from './tally';
import {
  SyncRecords, emptyRecords,
  transformLedger, transformLedgerGroup, transformStockItem, transformStockGroup,
  transformGodown, transformUnit, transformVoucher,
} from './transform';

// ─── Helpers ─────────────────────────────────────────────────────────────────

function num(v: any): number {
  if (v === null || v === undefined || v === '') return 0;
  const s = typeof v === 'string' ? v.replace(/,/g, '').trim() : String(v);
  const n = parseFloat(s);
  return Number.isFinite(n) ? n : 0;
}

function str(v: any): string | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s.length ? s : null;
}

/** Today in Tally date format: "2-Aug-2026" */
function today(): string {
  return tallyDate(new Date());
}

/** Yesterday in Tally date format — so incremental always covers at least yesterday+today */
function yesterday(): string {
  const d = new Date();
  d.setDate(d.getDate() - 1);
  return tallyDate(d);
}

function parseTallyDate(s: string): Date {
  // "DD-MMM-YYYY"
  const m = s.match(/^(\d{1,2})-([A-Za-z]{3})-(\d{4})$/);
  if (m) {
    const months: Record<string, number> = {
      Jan: 0, Feb: 1, Mar: 2, Apr: 3, May: 4, Jun: 5,
      Jul: 6, Aug: 7, Sep: 8, Oct: 9, Nov: 10, Dec: 11,
    };
    return new Date(parseInt(m[3]), months[m[2]], parseInt(m[1]));
  }
  // "YYYY-MM-DD"
  const iso = s.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (iso) return new Date(parseInt(iso[1]), parseInt(iso[2]) - 1, parseInt(iso[3]));
  return new Date(s);
}

function toTallyDate(isoOrTally: string): string {
  // If already in Tally format, return as-is
  if (/^\d{1,2}-[A-Za-z]{3}-\d{4}$/.test(isoOrTally)) return isoOrTally;
  return tallyDate(parseTallyDate(isoOrTally));
}

export function countRecords(r: SyncRecords): number {
  return Object.values(r).reduce((acc, v) => {
    if (Array.isArray(v)) return acc + v.length;
    return acc;
  }, 0);
}

// ─── Voucher type routing ────────────────────────────────────────────────────

const VOUCHER_TYPE_KEY: Record<string, keyof SyncRecords> = {
  'sales':        'sales_vouchers',
  'purchase':     'purchase_vouchers',
  'receipt':      'receipt_vouchers',
  'payment':      'payment_vouchers',
  'contra':       'contra_vouchers',
  'journal':      'journal_vouchers',
  'credit note':  'credit_notes',
  'debit note':   'debit_notes',
  'credit notes': 'credit_notes',
  'debit notes':  'debit_notes',
};

// ─── Outstanding derivation ──────────────────────────────────────────────────

function deriveOutstanding(ledgers: any[]): any[] {
  const rows: any[] = [];
  const todayIso = new Date().toISOString().slice(0, 10);
  for (const l of ledgers) {
    const closing = Number(l.closing_balance) || 0;
    if (closing === 0) continue;
    if (l.is_customer) {
      rows.push({ ledger_name: l.name, kind: 'receivable', amount: Math.abs(closing), overdue_amount: 0, as_of_date: todayIso });
    } else if (l.is_supplier) {
      rows.push({ ledger_name: l.name, kind: 'payable', amount: Math.abs(closing), overdue_amount: 0, as_of_date: todayIso });
    }
  }
  return rows;
}

// ─── Daybook derivation ──────────────────────────────────────────────────────

function buildDaybookFromVouchers(records: SyncRecords): any[] {
  const rows: any[] = [];
  const voucherKeys: (keyof SyncRecords)[] = [
    'sales_vouchers', 'purchase_vouchers', 'receipt_vouchers', 'payment_vouchers',
    'contra_vouchers', 'journal_vouchers', 'credit_notes', 'debit_notes',
  ];
  const typeMap: Record<string, string> = {
    sales_vouchers: 'Sales', purchase_vouchers: 'Purchase',
    receipt_vouchers: 'Receipt', payment_vouchers: 'Payment',
    contra_vouchers: 'Contra', journal_vouchers: 'Journal',
    credit_notes: 'Credit Note', debit_notes: 'Debit Note',
  };
  for (const key of voucherKeys) {
    const vType = typeMap[key] || key;
    for (const v of records[key] as any[]) {
      const entries = v.entries || v.ledger_entries || v.lines || [];
      if (entries.length === 0) {
        rows.push({ voucher_type: vType, voucher_number: v.voucher_number, voucher_date: v.voucher_date, ledger_name: null, debit: 0, credit: 0, narration: v.narration });
      } else {
        for (const e of entries) {
          rows.push({ voucher_type: vType, voucher_number: v.voucher_number, voucher_date: v.voucher_date, ledger_name: e.ledger_name, debit: e.debit, credit: e.credit, narration: e.narration || v.narration });
        }
      }
    }
  }
  return rows;
}

// ─── Voucher extraction ──────────────────────────────────────────────────────

/**
 * Fetch vouchers for a SINGLE DATE RANGE with one retry on failure.
 * Does NOT split into monthly/weekly batches — callers decide the date window.
 * Returns the number of vouchers collected.
 */
async function fetchVouchersForRange(
  tally: TallyClient,
  companyName: string,
  fromDate: string,
  toDate: string,
  records: SyncRecords,
  logger: Logger,
): Promise<number> {
  let vouchers: any[] = [];

  // Try COLLECTION first, fall back to Daybook
  try {
    vouchers = await tally.exportVouchersCollection(companyName, fromDate, toDate);
  } catch (collErr) {
    logger.info(`  Collection failed (${(collErr as Error).message}), trying Daybook...`);
    try {
      vouchers = await tally.exportVouchers(companyName, fromDate, toDate);
    } catch (dbErr) {
      logger.warn(`  Daybook also failed: ${(dbErr as Error).message}`);
      return 0;
    }
  }

  for (const v of vouchers) {
    const typeName = (v.voucher_type || v.vouchertypename || v.vouchertype || v.vchtype || '').toLowerCase().trim();
    const key = VOUCHER_TYPE_KEY[typeName];
    if (key) (records[key] as any[]).push(transformVoucher(v));
  }
  if (vouchers.length > 0) logger.info(`  Vouchers ${fromDate}→${toDate}: ${vouchers.length} fetched`);
  return vouchers.length;
}

// ─── Masters refresh ─────────────────────────────────────────────────────────

export async function refreshMasters(
  tally: TallyClient,
  companyName: string,
  logger: Logger,
): Promise<Pick<SyncRecords, 'ledger_groups' | 'ledgers' | 'stock_groups' | 'units' | 'godowns' | 'stock_items'>> {
  const records = {
    ledger_groups: [] as any[],
    ledgers: [] as any[],
    stock_groups: [] as any[],
    units: [] as any[],
    godowns: [] as any[],
    stock_items: [] as any[],
  };

  try {
    records.ledger_groups = (await tally.exportLedgerGroups(companyName)).map(transformLedgerGroup);
    logger.info(`Masters: ${records.ledger_groups.length} ledger groups`);
  } catch (e) { logger.warn(`ledger_groups: ${(e as Error).message}`); }

  try {
    records.ledgers = (await tally.exportLedgers(companyName)).map(transformLedger);
    logger.info(`Masters: ${records.ledgers.length} ledgers`);
  } catch (e) { logger.warn(`ledgers: ${(e as Error).message}`); }

  try {
    records.stock_groups = (await tally.exportStockGroups(companyName)).map(transformStockGroup);
    logger.info(`Masters: ${records.stock_groups.length} stock groups`);
  } catch (e) { logger.warn(`stock_groups: ${(e as Error).message}`); }

  try {
    records.units = (await tally.exportUnits(companyName)).map(transformUnit);
    logger.info(`Masters: ${records.units.length} units`);
  } catch (e) { logger.warn(`units: ${(e as Error).message}`); }

  try {
    records.godowns = (await tally.exportGodowns(companyName)).map(transformGodown);
    logger.info(`Masters: ${records.godowns.length} godowns`);
  } catch (e) { logger.warn(`godowns: ${(e as Error).message}`); }

  try {
    records.stock_items = (await tally.exportStockItems(companyName)).map(transformStockItem);
    logger.info(`Masters: ${records.stock_items.length} stock items`);
  } catch (e) { logger.warn(`stock_items: ${(e as Error).message}`); }

  return records;
}

// ─── Main sync function ──────────────────────────────────────────────────────

export interface IncrementalSyncOptions {
  /** Last voucher sync date in YYYY-MM-DD or Tally format. Null → sync from current FY start only. */
  lastVoucherSync: string | null;
  /** Whether masters need a refresh (>24h since last refresh, or explicitly requested). */
  refreshMastersNow: boolean;
}

/**
 * Incremental sync: fetches only new/changed vouchers since lastVoucherSync,
 * always refreshes outstanding balances and stock balances (lightweight),
 * and refreshes masters only when refreshMastersNow is true.
 *
 * Date window for vouchers:
 *   - If lastVoucherSync is set: from that date → today (typically just today or yesterday+today)
 *   - If null (first run): current FY start → today
 *
 * NEVER fetches historical data going back years — that crashed Tally.
 */
export async function runIncrementalSync(
  tally: TallyClient,
  companyName: string,
  options: IncrementalSyncOptions,
  logger: Logger,
): Promise<SyncRecords> {
  const records = emptyRecords();
  const toDate = today();

  // ── 1. Vouchers ──────────────────────────────────────────────────────────
  let fromDate: string;
  if (options.lastVoucherSync) {
    // Sync from last known date (use yesterday as safety net to avoid missing same-day entries)
    const lastDate = parseTallyDate(options.lastVoucherSync);
    lastDate.setDate(lastDate.getDate() - 1); // go back 1 day to be safe
    fromDate = tallyDate(lastDate);
  } else {
    // First run: sync from current FY start (1-Apr-2026)
    const now = new Date();
    const fyYear = now.getMonth() < 3 ? now.getFullYear() - 1 : now.getFullYear();
    fromDate = `1-Apr-${fyYear}`;
    logger.info(`First run: syncing vouchers from current FY start ${fromDate}`);
  }

  logger.info(`Syncing vouchers from ${fromDate} to ${toDate}`);

  // If the date range is > 7 days, split into weekly batches to avoid Tally timeouts
  const fromD = parseTallyDate(fromDate);
  const toD = parseTallyDate(toDate);
  const dayDiff = Math.ceil((toD.getTime() - fromD.getTime()) / 86400000);
  let voucherCount = 0;
  if (dayDiff > 7) {
    let cursor = new Date(fromD);
    while (cursor <= toD) {
      const weekEnd = new Date(cursor);
      weekEnd.setDate(weekEnd.getDate() + 6);
      if (weekEnd > toD) weekEnd.setTime(toD.getTime());
      voucherCount += await fetchVouchersForRange(tally, companyName, tallyDate(cursor), tallyDate(weekEnd), records, logger);
      cursor.setDate(cursor.getDate() + 7);
    }
  } else {
    voucherCount = await fetchVouchersForRange(tally, companyName, fromDate, toDate, records, logger);
  }
  logger.info(`Vouchers: ${voucherCount} total`);

  records.daybook = buildDaybookFromVouchers(records);

  // ── 2. Ledgers (always refresh — contains closing balances) ───────────────
  // Ledgers are small and fast; they must always be current so outstanding is accurate.
  try {
    const ledgers = await tally.exportLedgers(companyName);
    records.ledgers = ledgers.map(transformLedger);
    logger.info(`Ledgers: ${records.ledgers.length} (balances refreshed)`);
  } catch (e) { logger.warn(`ledgers refresh: ${(e as Error).message}`); }

  // ── 3. Stock balances (always refresh — changes with every sale/purchase) ──
  try {
    const stockItems = await tally.exportStockItems(companyName);
    records.stock_items = stockItems.map(transformStockItem);
    logger.info(`Stock items: ${records.stock_items.length} (balances refreshed)`);
  } catch (e) { logger.warn(`stock items refresh: ${(e as Error).message}`); }

  // ── 4. Outstanding (always refresh) ──────────────────────────────────────
  records.outstanding_balances = deriveOutstanding(records.ledgers);
  logger.info(`Outstanding: ${records.outstanding_balances.length} (derived from ledgers)`);

  // ── 5. Masters (only when due) ────────────────────────────────────────────
  if (options.refreshMastersNow) {
    logger.info('Refreshing masters (due for 24h refresh)...');
    const masters = await refreshMasters(tally, companyName, logger);
    // Override ledger_groups, stock_groups, units, godowns with fresh data
    // (ledgers and stock_items are already fetched above — don't double-fetch)
    records.ledger_groups = masters.ledger_groups;
    records.stock_groups = masters.stock_groups;
    records.units = masters.units;
    records.godowns = masters.godowns;
  }

  logger.info(`Incremental sync done for ${companyName}: ${countRecords(records)} records`);
  return records;
}

/**
 * Force full sync — ONLY called explicitly by the user via the Settings UI.
 * Fetches current FY vouchers + all masters. Never fetches 2023 data.
 */
export async function runForceFullSync(
  tally: TallyClient,
  companyName: string,
  logger: Logger,
): Promise<SyncRecords> {
  logger.info(`Force full sync for ${companyName} — current FY only`);
  const records = emptyRecords();

  // Masters
  const masters = await refreshMasters(tally, companyName, logger);
  records.ledger_groups = masters.ledger_groups;
  records.ledgers = masters.ledgers;
  records.stock_groups = masters.stock_groups;
  records.units = masters.units;
  records.godowns = masters.godowns;
  records.stock_items = masters.stock_items;

  // Current FY vouchers only
  const now = new Date();
  const fyYear = now.getMonth() < 3 ? now.getFullYear() - 1 : now.getFullYear();
  const fromDate = `1-Apr-${fyYear}`;
  const toDate = today();
  logger.info(`Force full sync: fetching vouchers ${fromDate} → ${toDate}`);

  // Split into monthly batches to avoid overwhelming Tally
  const cursor = parseTallyDate(fromDate);
  const end = parseTallyDate(toDate);
  while (cursor <= end) {
    const monthEnd = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
    const batchTo = monthEnd > end ? end : monthEnd;
    const batchFrom = tallyDate(cursor);
    const batchToStr = tallyDate(batchTo);
    const count = await fetchVouchersForRange(tally, companyName, batchFrom, batchToStr, records, logger);
    if (count > 0) logger.info(`  ${batchFrom}→${batchToStr}: ${count} vouchers`);
    cursor.setMonth(cursor.getMonth() + 1);
    cursor.setDate(1);
  }

  records.daybook = buildDaybookFromVouchers(records);
  records.outstanding_balances = deriveOutstanding(records.ledgers);
  logger.info(`Force full sync done for ${companyName}: ${countRecords(records)} records`);
  return records;
}
