import * as winston from 'winston';
import * as path from 'path';
import { AgentConfig } from './config';

export function createLogger(config: AgentConfig): winston.Logger {
  return winston.createLogger({
    level: config.log_level || 'info',
    format: winston.format.combine(
      winston.format.timestamp(),
      winston.format.printf(({ timestamp, level, message }) => `${timestamp} [${level.toUpperCase()}] ${message}`)
    ),
    transports: [
      new winston.transports.Console({ format: winston.format.colorize() }),
      new winston.transports.File({
        filename: path.join(config.log_dir, 'agent.log'),
        maxsize: 5 * 1024 * 1024,
        maxFiles: 7,
      }),
      new winston.transports.File({
        filename: path.join(config.log_dir, 'error.log'),
        level: 'error',
        maxsize: 5 * 1024 * 1024,
        maxFiles: 7,
      }),
    ],
  });
}
