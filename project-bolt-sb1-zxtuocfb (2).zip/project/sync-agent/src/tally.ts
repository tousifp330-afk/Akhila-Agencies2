import axios, { AxiosInstance } from 'axios';
import { XMLParser } from 'fast-xml-parser';
import { AgentConfig } from './config';
import { Logger } from 'winston';

/**
 * TallyPrime XML API client — hybrid collection strategy.
 *
 * MASTERS (ledger groups, ledgers, stock groups, stock items, godowns):
 *   Use built-in collection IDs ("List of Groups", "List of Ledgers", etc.).
 *   These work reliably for master data across TallyPrime versions and
 *   return clean XML via the EXPORT/COLLECTION engine.
 *
 * UNITS:
 *   "List of Units" does NOT exist in all TallyPrime versions and causes
 *   "Could not find description!" errors. Instead we use an inline TDL
 *   collection with a SAFE NATIVEMETHOD — only Name (the built-in method),
 *   NOT Guid or Issuer which cause memory access violations.
 *
 * VOUCHERS:
 *   Uses Tally's built-in "Daybook" DATA export (TYPE=DATA, ID=Daybook).
 *   This is a native Tally report present in every version including EDU.
 *   It returns all vouchers for the date range in TALLYMESSAGE/VOUCHER nodes.
 *   One request per date range; voucher type filtering is done client-side.
 *   This approach never triggers "Collection: List of Vouchers" errors and
 *   never requires inline TDL or CHILDOF.
 *
 * RESILIENCE:
 *   postXmlWithRetry wraps every request with exponential backoff, AbortController
 *   timeout, and automatic reconnection wait when Tally becomes unresponsive.
 */

const parser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  parseAttributeValue: true,
  parseTagValue: false,
  trimValues: true,
  textNodeName: '#text',
  isArray: (name: string) => {
    return [
      'LEDGER', 'GROUP', 'STOCKITEM', 'STOCKGROUP', 'GODOWN', 'UNIT',
      'VOUCHER', 'TALLYMESSAGE',
      'LEDGERENTRIES.LIST', 'ALLINVENTORYENTRIES.LIST',
      'BANKALLOCATIONS.LIST', 'BILLALLOCATIONS.LIST',
      'INVENTORYENTRIES.LIST', 'ADDRESS.LIST', 'DATERANGE',
    ].includes(name);
  },
});

function escapeXml(s: string): string {
  return String(s == null ? '' : s).replace(/[<>&'"]/g, c => ({
    '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;',
  }[c] as string));
}

export function tallyDate(d: Date): string {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return `${d.getDate()}-${months[d.getMonth()]}-${d.getFullYear()}`;
}

export class TallyClient {
  private http: AxiosInstance;
  private logger: Logger;
  public endpoint: string;

  constructor(config: AgentConfig, logger: Logger) {
    this.endpoint = config.tally_endpoint;
    this.logger = logger;
    this.http = axios.create({
      baseURL: this.endpoint,
      timeout: 120000,
      headers: { 'Content-Type': 'text/xml', 'Accept': 'text/xml' },
      responseType: 'text',
      maxContentLength: Infinity,
      maxBodyLength: Infinity,
    });
  }

  async postXml(envelope: string): Promise<any> {
    return this.postXmlWithRetry(envelope);
  }

  /**
   * Send XML to Tally with retry, exponential backoff, timeout abort, and
   * automatic reconnection when Tally becomes unresponsive.
   */
  private async postXmlWithRetry(envelope: string, maxRetries = 1): Promise<any> {
    let lastErr: Error | null = null;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      if (attempt > 0) {
        const delay = Math.min(2000 * 2 ** (attempt - 1), 30000);
        this.logger.warn(`Retrying Tally request in ${delay}ms (attempt ${attempt + 1}/${maxRetries + 1})`);
        await sleep(delay);
        await this.waitForResponsive();
      }
      try {
        const text = await this.postXmlOnce(envelope, 30000);
        return this.parseResponse(text);
      } catch (e) {
        lastErr = e as Error;
        const msg = (e as Error).message;
        if (/ECONNRESET|timeout|aborted|ECONNREFUSED|socket hang up/i.test(msg)) {
          this.logger.warn(`Tally request failed: ${msg}`);
          continue;
        }
        throw e;
      }
    }
    throw lastErr || new Error('Tally request failed after retries');
  }

  /**
   * Single HTTP POST with a hard Promise.race timeout.
   * AbortController alone does not guarantee the Promise settles in Node.js
   * because the underlying socket can stay open. Promise.race ensures the
   * caller always gets a resolution or rejection within timeoutMs.
   */
  private async postXmlOnce(envelope: string, timeoutMs = 60000): Promise<string> {
    const requestPromise = this.http.post('', envelope).then((res: any) => {
      if (res.status !== 200) throw new Error(`Tally HTTP ${res.status}`);
      const text = res.data;
      if (!text || text.length === 0) throw new Error('Tally returned empty response');
      if (!text.includes('<ENVELOPE')) {
        throw new Error(`Tally returned non-XML response (no <ENVELOPE>): ${text.substring(0, 300)}`);
      }
      return text as string;
    });

    const timeoutPromise = new Promise<never>((_, reject) => {
      setTimeout(() => {
        reject(new Error(`Tally request timed out after ${timeoutMs}ms`));
      }, timeoutMs);
    });

    return Promise.race([requestPromise, timeoutPromise]);
  }

  private parseResponse(text: string): any {
    if (text.includes('<LINEERROR>') || text.includes('Could not find description')) {
      const errMatch = text.match(/<LINEERROR>(.*?)<\/LINEERROR>/);
      if (errMatch) throw new Error(`TDL error: ${errMatch[1]}`);
    }
    try {
      return parser.parse(text);
    } catch (e) {
      const snippet = text.substring(0, 500);
      throw new Error(`XML parse error: ${(e as Error).message} | start: ${snippet}`);
    }
  }

  /**
   * Check if Tally is responsive (quick ping). Does not throw.
   */
  async isResponsive(): Promise<boolean> {
    try {
      const text = await this.postXmlOnce(this.buildBuiltInEnvelope('List of Companies', ''), 10000);
      return text.includes('<ENVELOPE');
    } catch { return false; }
  }

  /**
   * Wait for Tally to become responsive again after a freeze.
   * Polls every 5s, up to 2 minutes. Returns true if Tally recovered.
   */
  async waitForResponsive(maxWaitMs = 120000): Promise<boolean> {
    const deadline = Date.now() + maxWaitMs;
    while (Date.now() < deadline) {
      this.logger.info('Waiting for Tally to recover...');
      await sleep(5000);
      if (await this.isResponsive()) {
        this.logger.info('Tally is responsive again');
        return true;
      }
    }
    this.logger.error('Tally did not recover within timeout');
    return false;
  }

  // ============================================================
  // Built-in collection requests (masters)
  // ============================================================

  /**
   * Build a COLLECTION request using a built-in collection ID.
   * No inline TDL — relies on Tally's built-in collection definitions.
   */
  private buildBuiltInEnvelope(
    collectionId: string,
    company: string,
    fromDate?: string,
    toDate?: string,
  ): string {
    const vars: string[] = [];
    if (company) vars.push(`<SVCURRENTCOMPANY>${escapeXml(company)}</SVCURRENTCOMPANY>`);
    if (fromDate) vars.push(`<SVFROMDATE TYPE="Date">${escapeXml(fromDate)}</SVFROMDATE>`);
    if (toDate) vars.push(`<SVTODATE TYPE="Date">${escapeXml(toDate)}</SVTODATE>`);
    vars.push(`<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>`);

    return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>COLLECTION</TYPE>
    <ID>${escapeXml(collectionId)}</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>${vars.join('')}</STATICVARIABLES>
    </DESC>
  </BODY>
</ENVELOPE>`;
  }

  /**
   * Build a COLLECTION request with inline TDL collection definition.
   * Used only for collections that don't have a reliable built-in ID.
   */
  private buildInlineEnvelope(
    collectionName: string,
    company: string,
    tdlCollection: string,
    fromDate?: string,
    toDate?: string,
  ): string {
    const vars: string[] = [];
    if (company) vars.push(`<SVCURRENTCOMPANY>${escapeXml(company)}</SVCURRENTCOMPANY>`);
    if (fromDate) vars.push(`<SVFROMDATE TYPE="Date">${escapeXml(fromDate)}</SVFROMDATE>`);
    if (toDate) vars.push(`<SVTODATE TYPE="Date">${escapeXml(toDate)}</SVTODATE>`);
    vars.push(`<SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT>`);

    return `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>COLLECTION</TYPE>
    <ID>${escapeXml(collectionName)}</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>${vars.join('')}</STATICVARIABLES>
      <TDL><TDLMESSAGE>${tdlCollection}</TDLMESSAGE></TDL>
    </DESC>
  </BODY>
</ENVELOPE>`;
  }

  async ping(): Promise<boolean> {
    try {
      const parsed = await this.postXml(this.buildBuiltInEnvelope('List of Companies', ''));
      return !!(parsed?.ENVELOPE?.BODY);
    } catch { return false; }
  }

  async listCompanies(): Promise<string[]> {
    try {
      const parsed = await this.postXml(this.buildBuiltInEnvelope('List of Companies', ''));
      const items = extractCollection(parsed, 'COMPANY');
      return items.map((c: any) => c.name).filter((n: any) => n).map(String);
    } catch (e) { this.logger.error(`listCompanies: ${(e as Error).message}`); return []; }
  }

  async getActiveCompany(): Promise<string | null> {
    try {
      const envelope = `<ENVELOPE><HEADER><VERSION>1</VERSION><TALLYREQUEST>EXPORT</TALLYREQUEST><TYPE>OBJECT</TYPE><ID>Company</ID></HEADER><BODY><DESC><STATICVARIABLES><SVEXPORTFORMAT>$$SysName:XML</SVEXPORTFORMAT></STATICVARIABLES></DESC></BODY></ENVELOPE>`;
      const parsed = await this.postXml(envelope);
      const name = parsed?.ENVELOPE?.BODY?.DATA?.TALLYMESSAGE?.COMMPANY?.NAME
        ?? parsed?.ENVELOPE?.BODY?.DATA?.COLLECTION?.COMPANY?.['@_NAME']
        ?? parsed?.ENVELOPE?.BODY?.DATA?.COLLECTION?.COMMPANY?.NAME;
      return name ? String(name).trim() : null;
    } catch { return null; }
  }

  // --- Masters using inline TDL with NATIVEMETHOD (full data) ---

  async exportLedgerGroups(company: string): Promise<any[]> {
    const tdl = `<COLLECTION NAME="SyncGroups" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Group</TYPE>
  <NATIVEMETHOD>Name,Parent,Nature,BuiltinIsReserved</NATIVEMETHOD>
</COLLECTION>`;
    const parsed = await this.postXml(this.buildInlineEnvelope('SyncGroups', company, tdl));
    return extractCollection(parsed, 'GROUP');
  }

  async exportLedgers(company: string): Promise<any[]> {
    const tdl = `<COLLECTION NAME="SyncLedgers" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Ledger</TYPE>
  <NATIVEMETHOD>Name,Parent,OpeningBalance,ClosingBalance,GSTNumber,Phone,MailingAddress</NATIVEMETHOD>
</COLLECTION>`;
    const parsed = await this.postXml(this.buildInlineEnvelope('SyncLedgers', company, tdl));
    return extractCollection(parsed, 'LEDGER');
  }

  async exportStockGroups(company: string): Promise<any[]> {
    const tdl = `<COLLECTION NAME="SyncStockGroups" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Stock Group</TYPE>
  <NATIVEMETHOD>Name,Parent</NATIVEMETHOD>
</COLLECTION>`;
    const parsed = await this.postXml(this.buildInlineEnvelope('SyncStockGroups', company, tdl));
    return extractCollection(parsed, 'STOCKGROUP');
  }

  async exportStockItems(company: string): Promise<any[]> {
    const tdl = `<COLLECTION NAME="SyncStockItems" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Stock Item</TYPE>
  <NATIVEMETHOD>Name,Parent,BaseUnits,OpeningBalance,OpeningValue,ClosingBalance,ClosingValue,StandardPrice</NATIVEMETHOD>
</COLLECTION>`;
    const parsed = await this.postXml(this.buildInlineEnvelope('SyncStockItems', company, tdl));
    return extractCollection(parsed, 'STOCKITEM');
  }

  async exportGodowns(company: string): Promise<any[]> {
    const tdl = `<COLLECTION NAME="SyncGodowns" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Godown</TYPE>
  <NATIVEMETHOD>Name,Parent</NATIVEMETHOD>
</COLLECTION>`;
    const parsed = await this.postXml(this.buildInlineEnvelope('SyncGodowns', company, tdl));
    return extractCollection(parsed, 'GODOWN');
  }

  // --- Units: inline TDL with SAFE NATIVEMETHOD (Name only) ---

  /**
   * Export units of measure using inline TDL.
   * "List of Units" built-in ID doesn't exist in all TallyPrime versions.
   * We use an inline collection with NATIVEMETHOD=Name only — NOT Guid or
   * Issuer, which are NOT valid object methods for the Unit type and cause
   * memory access violations (c0000005).
   */
  async exportUnits(company: string): Promise<any[]> {
    const tdl = `<COLLECTION NAME="SyncUnits" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Unit</TYPE>
  <NATIVEMETHOD>Name</NATIVEMETHOD>
</COLLECTION>`;
    const parsed = await this.postXml(this.buildInlineEnvelope('SyncUnits', company, tdl));
    return extractCollection(parsed, 'UNIT');
  }

  // --- Vouchers: Daybook DATA export (works in all TallyPrime versions) ---

  /**
   * Export ALL vouchers for a date range using the built-in Daybook report.
   * Returns raw normalized voucher nodes (all types mixed together).
   * The caller filters by voucherTypeName client-side.
   *
   * Why Daybook and not "List of Vouchers":
   *   "Collection: List of Vouchers" does not exist in TallyPrime EDU and
   *   throws "Could not find description!". The Daybook DATA export is a
   *   native report in every Tally version and requires no TDL definition.
   */
  async exportVouchers(
    company: string, fromDate: string, toDate: string,
  ): Promise<any[]> {
    this.logger.info(`[VOUCHER] Daybook request: company=${company}, from=${fromDate}, to=${toDate}`);
    const envelope = `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>DATA</TYPE>
    <ID>Daybook</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVCURRENTCOMPANY>${escapeXml(company)}</SVCURRENTCOMPANY>
        <SVFROMDATE TYPE="Date">${escapeXml(fromDate)}</SVFROMDATE>
        <SVTODATE TYPE="Date">${escapeXml(toDate)}</SVTODATE>
        <SVEXPORTFORMAT>$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>
    </DESC>
  </BODY>
</ENVELOPE>`;
    this.logger.info(`[VOUCHER] Daybook request: from=${fromDate}, to=${toDate}`);
    const parsed = await this.postXml(envelope);
    const vouchers = extractDaybookVouchers(parsed);
    this.logger.info(`[VOUCHER] Daybook extracted ${vouchers.length} vouchers`);
    return vouchers;
  }

  async exportOutstandingReceivable(company: string): Promise<any[]> {
    this.logger.info(`[OUTSTANDING] Receivable request for ${company}`);

    // Approach 1: inline COLLECTION of Bill objects (most reliable in TallyPrime 6.x)
    const tdl = `<COLLECTION NAME="SyncBillsRec" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Bill</TYPE>
  <FILTER>IsReceivable</FILTER>
  <NATIVEMETHOD>Name,PartyLedgerName,BillDate,BillDueDate,PendingAmount</NATIVEMETHOD>
</COLLECTION>`;
    try {
      const parsed = await this.postXml(this.buildInlineEnvelope('SyncBillsRec', company, tdl));
      const bills = extractCollection(parsed, 'BILL');
      this.logger.info(`[OUTSTANDING] Receivable extracted ${bills.length} bills (collection)`);
      return bills;
    } catch (e) {
      this.logger.warn(`[OUTSTANDING] Receivable collection failed: ${(e as Error).message}`);
    }

    // Approach 2: DATA export with report name
    const envelope = `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>DATA</TYPE>
    <ID>Bills Receivable</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVCURRENTCOMPANY>${escapeXml(company)}</SVCURRENTCOMPANY>
        <SVEXPORTFORMAT>$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>
    </DESC>
  </BODY>
</ENVELOPE>`;
    try {
      const parsed = await this.postXml(envelope);
      const bills = extractBills(parsed);
      this.logger.info(`[OUTSTANDING] Receivable extracted ${bills.length} bills (data export)`);
      return bills;
    } catch (e) {
      this.logger.warn(`[OUTSTANDING] Receivable export failed: ${(e as Error).message}`);
      return [];
    }
  }

  async exportOutstandingPayable(company: string): Promise<any[]> {
    this.logger.info(`[OUTSTANDING] Payable request for ${company}`);

    // Approach 1: inline COLLECTION of Bill objects
    const tdl = `<COLLECTION NAME="SyncBillsPay" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Bill</TYPE>
  <FILTER>IsPayable</FILTER>
  <NATIVEMETHOD>Name,PartyLedgerName,BillDate,BillDueDate,PendingAmount</NATIVEMETHOD>
</COLLECTION>`;
    try {
      const parsed = await this.postXml(this.buildInlineEnvelope('SyncBillsPay', company, tdl));
      const bills = extractCollection(parsed, 'BILL');
      this.logger.info(`[OUTSTANDING] Payable extracted ${bills.length} bills (collection)`);
      return bills;
    } catch (e) {
      this.logger.warn(`[OUTSTANDING] Payable collection failed: ${(e as Error).message}`);
    }

    // Approach 2: DATA export with report name
    const envelope = `<ENVELOPE>
  <HEADER>
    <VERSION>1</VERSION>
    <TALLYREQUEST>EXPORT</TALLYREQUEST>
    <TYPE>DATA</TYPE>
    <ID>Bills Payable</ID>
  </HEADER>
  <BODY>
    <DESC>
      <STATICVARIABLES>
        <SVCURRENTCOMPANY>${escapeXml(company)}</SVCURRENTCOMPANY>
        <SVEXPORTFORMAT>$SysName:XML</SVEXPORTFORMAT>
      </STATICVARIABLES>
    </DESC>
  </BODY>
</ENVELOPE>`;
    try {
      const parsed = await this.postXml(envelope);
      const bills = extractBills(parsed);
      this.logger.info(`[OUTSTANDING] Payable extracted ${bills.length} bills (data export)`);
      return bills;
    } catch (e) {
      this.logger.warn(`[OUTSTANDING] Payable export failed: ${(e as Error).message}`);
      return [];
    }
  }

  /**
   * Export vouchers for a date range using inline TDL COLLECTION.
   * More reliable than Daybook DATA export in some TallyPrime versions.
   * Returns vouchers with full ledger + inventory entries via NATIVEMETHOD.
   */
  async exportVouchersCollection(
    company: string, fromDate: string, toDate: string,
  ): Promise<any[]> {
    const tdl = `<COLLECTION NAME="SyncVouchers" ISMODIFY="No" ISFIXED="No" ISINITIALIZE="No" ISOPTION="No" ISINTERNAL="No">
  <TYPE>Voucher</TYPE>
  <NATIVEMETHOD>Date,VoucherNumber,VoucherTypeName,PartyLedgerName,Narration,LedgerEntries,AllInventoryEntries</NATIVEMETHOD>
</COLLECTION>`;
    this.logger.info(`[VOUCHER] Collection request: from=${fromDate}, to=${toDate}`);
    const parsed = await this.postXml(this.buildInlineEnvelope('SyncVouchers', company, tdl, fromDate, toDate));
    const vouchers = extractCollection(parsed, 'VOUCHER');
    this.logger.info(`[VOUCHER] Collection extracted ${vouchers.length} vouchers`);
    return vouchers;
  }
}

// ============================================================
// XML response extraction helpers
// ============================================================

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Extract vouchers from a Daybook DATA export response.
 * The Daybook report wraps vouchers in TALLYMESSAGE nodes:
 *   ENVELOPE/BODY/DATA/TALLYMESSAGE/VOUCHER
 * This is different from collection exports which use:
 *   ENVELOPE/BODY/DATA/COLLECTION/<type>
 */
function extractDaybookVouchers(parsed: any): any[] {
  if (!parsed?.ENVELOPE?.BODY?.DATA) return [];
  const data = parsed.ENVELOPE.BODY.DATA;
  // TALLYMESSAGE may be an array (multiple vouchers) or single object
  const messages: any[] = Array.isArray(data.TALLYMESSAGE)
    ? data.TALLYMESSAGE
    : data.TALLYMESSAGE ? [data.TALLYMESSAGE] : [];
  const vouchers: any[] = [];
  for (const msg of messages) {
    if (!msg) continue;
    const v = msg.VOUCHER;
    if (!v) continue;
    if (Array.isArray(v)) vouchers.push(...v.map(normalizeNode));
    else vouchers.push(normalizeNode(v));
  }
  return vouchers;
}

function extractBills(parsed: any): any[] {
  if (!parsed?.ENVELOPE?.BODY?.DATA) return [];
  const data = parsed.ENVELOPE.BODY.DATA;
  const messages: any[] = Array.isArray(data.TALLYMESSAGE)
    ? data.TALLYMESSAGE
    : data.TALLYMESSAGE ? [data.TALLYMESSAGE] : [];
  const bills: any[] = [];
  for (const msg of messages) {
    if (!msg) continue;
    const billNodes = msg.BILL || msg.BILLS || msg.BILLDETAILS;
    if (!billNodes) continue;
    const arr = Array.isArray(billNodes) ? billNodes : [billNodes];
    for (const b of arr) {
      if (b) bills.push(normalizeNode(b));
    }
  }
  return bills;
}

function extractCollection(parsed: any, tagName: string): any[] {
  if (!parsed?.ENVELOPE?.BODY?.DATA) return [];
  const data = parsed.ENVELOPE.BODY.DATA;
  const collNode = data.COLLECTION || data;
  const items = findTagRecursive(collNode, tagName);
  return items.map(normalizeNode);
}

function findTagRecursive(node: any, tagName: string): any[] {
  const results: any[] = [];
  if (node == null) return results;
  if (Array.isArray(node)) { node.forEach((i) => results.push(...findTagRecursive(i, tagName))); return results; }
  if (typeof node === 'object') {
    for (const [key, value] of Object.entries(node)) {
      if (key.toUpperCase() === tagName.toUpperCase()) {
        if (Array.isArray(value)) results.push(...value);
        else results.push(value);
      } else {
        results.push(...findTagRecursive(value, tagName));
      }
    }
  }
  return results;
}

function normalizeNode(node: any): any {
  if (node == null || typeof node !== 'object') return node;
  if (Array.isArray(node)) return node.map(normalizeNode);

  const keys = Object.keys(node);

  // Tally wraps values like <PARENT TYPE="String">Sundry Debtors</PARENT>
  // → { "@_TYPE": "String", "#text": "Sundry Debtors" }
  // Extract the text value directly when only attrs + #text are present.
  if ('#text' in node && keys.every(k => k === '#text' || k.startsWith('@_'))) {
    const textVal = node['#text'];
    return typeof textVal === 'object' ? null : textVal;
  }

  const result: any = {};
  for (const [key, value] of Object.entries(node)) {
    if (key === '#text') continue;
    // Keep attributes with @_ prefix stripped (NAME → name, GUID → guid, etc.)
    const cleanKey = key.replace(/^@_/, '').replace(/\s+/g, '_').toLowerCase();
    result[cleanKey] = normalizeNode(value);
  }
  return result;
}
