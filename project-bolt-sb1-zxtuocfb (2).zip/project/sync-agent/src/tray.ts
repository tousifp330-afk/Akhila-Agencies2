import SysTray2, { MenuItem, Action, ClickEvent } from 'systray2';
import { Logger } from 'winston';
import * as path from 'path';
import * as fs from 'fs';

export interface TrayHandlers {
  onSyncNow: () => Promise<void>;
  onToggleAutoSync: () => void;
  isAutoSyncEnabled: () => boolean;
  onExit: () => void;
  getStatusText: () => string;
}

const MENU_SYNC = 'Sync Now';
const MENU_TOGGLE = 'Toggle Auto-Sync';
const MENU_STATUS = 'Status';
const MENU_EXIT = 'Exit';

function statusItem(text: string): MenuItem {
  return { title: `${MENU_STATUS}: ${text}`, tooltip: 'Agent status', enabled: false };
}

export function createTray(handlers: TrayHandlers, logger: Logger): SysTray2 | null {
  try {
    const iconPath = path.join(__dirname, '..', 'icon.ico');
    const icon = fs.existsSync(iconPath)
      ? fs.readFileSync(iconPath).toString('base64')
      : '';

    const menu = [
      statusItem(handlers.getStatusText()),
      { title: MENU_SYNC, tooltip: 'Trigger sync now', enabled: true },
      { title: MENU_TOGGLE, tooltip: 'Enable/disable auto sync', enabled: true },
      { title: MENU_EXIT, tooltip: 'Exit the agent', enabled: true },
    ];

    const tray = new SysTray2({
      menu: {
        icon,
        title: 'Akhila ERP Sync',
        tooltip: 'Akhila ERP Sync Agent',
        items: menu,
      },
      debug: false,
      copyDir: true,
    });

    tray.onReady(() => {
      logger.info('System tray ready');
    });

    tray.onClick(async (action: ClickEvent) => {
      const title = action.item.title;
      try {
        if (title.startsWith(MENU_SYNC)) {
          await handlers.onSyncNow();
        } else if (title.startsWith(MENU_TOGGLE)) {
          handlers.onToggleAutoSync();
        } else if (title.startsWith(MENU_EXIT)) {
          handlers.onExit();
          await tray.kill(false);
          return;
        }
        // Update status item
        const updatedMenu = [
          statusItem(handlers.getStatusText()),
          { title: MENU_SYNC, tooltip: 'Trigger sync now', enabled: true },
          { title: MENU_TOGGLE, tooltip: 'Enable/disable auto sync', enabled: true },
          { title: MENU_EXIT, tooltip: 'Exit the agent', enabled: true },
        ];
        const updateAction: Action = {
          type: 'update-menu',
          menu: {
            icon,
            title: 'Akhila ERP Sync',
            tooltip: 'Akhila ERP Sync Agent',
            items: updatedMenu,
          },
        };
        await tray.sendAction(updateAction);
      } catch (e) {
        logger.warn(`Tray click error: ${(e as Error).message}`);
      }
    });

    tray.onError((err: Error) => {
      logger.warn(`Tray error: ${err.message}`);
    });

    return tray;
  } catch (e) {
    logger.warn(`Tray unavailable: ${(e as Error).message}`);
    return null;
  }
}
