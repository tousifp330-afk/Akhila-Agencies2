import * as path from 'path';
import * as fs from 'fs';
import { Logger } from 'winston';

const REG_KEY = 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Run';
const APP_NAME = 'AkhilaERPSyncAgent';

export async function enableAutoStart(logger: Logger): Promise<void> {
  if (process.platform !== 'win32') {
    logger.debug('Auto-start only supported on Windows');
    return;
  }
  try {
    const WinReg = require('winreg');
    const reg = new WinReg({ hive: WinReg.HKCU, key: REG_KEY });
    const exePath = process.execPath;
    const agentPath = path.join(__dirname, 'index.js');
    const cmd = `"${exePath}" "${agentPath}"`;
    reg.set(APP_NAME, WinReg.REG_SZ, cmd, (err: Error | null) => {
      if (err) logger.warn(`Failed to set autostart: ${err.message}`);
      else logger.info(`Auto-start registered: ${cmd}`);
    });
  } catch (e) {
    logger.warn(`Auto-start not available: ${(e as Error).message}`);
  }
}

export async function disableAutoStart(logger: Logger): Promise<void> {
  if (process.platform !== 'win32') return;
  try {
    const WinReg = require('winreg');
    const reg = new WinReg({ hive: WinReg.HKCU, key: REG_KEY });
    reg.remove(APP_NAME, (err: Error | null) => {
      if (err && !/not found/i.test(err.message)) logger.warn(`Failed to remove autostart: ${err.message}`);
      else logger.info('Auto-start removed');
    });
  } catch (e) {
    logger.warn(`Auto-start removal not available: ${(e as Error).message}`);
  }
}
