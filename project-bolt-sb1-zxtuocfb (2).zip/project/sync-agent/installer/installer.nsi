; Akhila ERP Sync Agent — NSIS Installer
; Build with: makensis installer.nsi

Unicode true
ManifestDPIAware true
Name "Akhila ERP Sync Agent"
OutFile "AkhilaERPSyncAgent-Setup.exe"
InstallDir "$LOCALAPPDATA\AkhilaERPSyncAgent"
RequestExecutionLevel user
ShowInstDetails show

Page directory
Page instfiles

Section "Install"
  SetOutPath "$INSTDIR"
  File /r "dist"
  File /r "node_modules"
  File /r "assets"
  File "package.json"
  File "config.example.json"

  ; Create user config if missing
  IfFileExists "$INSTDIR\config.json" skip_config
    FileOpen $0 "$INSTDIR\config.json" w
    FileClose $0
  skip_config:

  ; Create start menu shortcut
  CreateDirectory "$SMPROGRAMS\Akhila ERP"
  CreateShortcut "$SMPROGRAMS\Akhila ERP\Sync Agent.lnk" "$INSTDIR\node.exe" '"$INSTDIR\dist\index.js"' "$INSTDIR\assets\icon.ico" 0

  ; Add to Windows startup (current user)
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "AkhilaERPSyncAgent" '"$INSTDIR\node.exe" "$INSTDIR\dist\index.js"'

  WriteUninstaller "$INSTDIR\uninstall.exe"
SectionEnd

Section "Uninstall"
  Delete "$SMPROGRAMS\Akhila ERP\Sync Agent.lnk"
  RMDir /r "$SMPROGRAMS\Akhila ERP"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "AkhilaERPSyncAgent"
  RMDir /r "$INSTDIR"
SectionEnd
