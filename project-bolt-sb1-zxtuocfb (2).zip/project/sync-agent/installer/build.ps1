# Build the Akhila ERP Sync Agent installer (Windows)
# Prerequisites: Node.js 20+, NSIS (makensis on PATH)

$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root

Write-Host "Installing dependencies..."
npm install --omit=dev --no-audit --no-fund

Write-Host "Compiling TypeScript..."
npm run build

Write-Host "Building installer..."
Push-Location installer
makensis installer.nsi
Pop-Location

Write-Host "Done. Installer at: installer\AkhilaERPSyncAgent-Setup.exe"
